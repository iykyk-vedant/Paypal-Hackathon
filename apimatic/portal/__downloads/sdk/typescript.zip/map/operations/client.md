<!-- Generated file — do not edit; regenerated with the SDK. -->

# CorridorFlowCrossBorderTradePrototypeApiClient — ungrouped operations

Accessor: `client` (the client itself) · Source: `src/client.ts` · 24 operations · Request and error types: namespace `CorridorFlowCrossBorderTradePrototypeApiClient`

Operations the spec leaves untagged are methods on the client rather than on a resource, so there is no accessor property to go through. The request type still lives in a namespace merged onto the exported class, so you write `CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankRequest`.

**Type sources**: every type an operation names, with the file that declares it and the schema value exported beside it. Import every name from `corridor-flow-cross-border-trade-prototype-api`; the `Source` path is where to **read** the shape, never what to import. `ApiError`, the runtime error family and the file vocabulary are excluded — see sdk-map.md.

### acceptAFabricTradeProposalAsTheCounterpartyBank

- **Signature**: `acceptAFabricTradeProposalAsTheCounterpartyBank(request: CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankRequest, options?: RequestOptions): ApiPromise<undefined, CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankError>`
- **Wire**: `POST /api/fabric/trades/{tradeId}/accept`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"`, an instance of `CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error400"` [400] no body · `"error503"` [503] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankRequest` (2):

| Field | Channel | Wire | Type | Req |
| --- | --- | --- | --- | --- |
| `tradeId` | `path` | — | `string` | yes |
| `xFabricWriteToken` | `header` | `X-Fabric-Write-Token` | `string` | yes |

### calculateIndicativeDemoQuoteWithOptionalGeminiExplanation

- **Signature**: `calculateIndicativeDemoQuoteWithOptionalGeminiExplanation(request?: CorridorFlowCrossBorderTradePrototypeApiClient.CalculateIndicativeDemoQuoteWithOptionalGeminiExplanationRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `POST /api/ai/negotiate`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field. **Optional**: omit it and the request carries no body and no `Content-Type` header at all
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.CalculateIndicativeDemoQuoteWithOptionalGeminiExplanationRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `ApiAiNegotiateRequest` | no |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiAiNegotiateRequest` | `apiAiNegotiateRequestSchema` | `src/models/api-ai-negotiate-request.ts` |

### capturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedger

- **Signature**: `capturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedger(request: CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerRequest, options?: RequestOptions): ApiPromise<undefined, CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError>`
- **Wire**: `POST /api/paypal/orders/{id}/capture`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"`, an instance of `CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error409"` [409] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerRequest` (2):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `id` | `path` | `string` | yes |
| `body` | `body` | `ApiPaypalOrdersCaptureRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiPaypalOrdersCaptureRequest` | `apiPaypalOrdersCaptureRequestSchema` | `src/models/api-paypal-orders-capture-request.ts` |

### checkFabricGatewayQueryConnectivity

- **Signature**: `checkFabricGatewayQueryConnectivity(options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `GET /api/fabric/status`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

### commitOneFabricSettlementLegDebitOrPayeeCredit

- **Signature**: `commitOneFabricSettlementLegDebitOrPayeeCredit(request: CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditRequest, options?: RequestOptions): ApiPromise<undefined, CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditError>`
- **Wire**: `POST /api/fabric/trades/{tradeId}/legs/{leg}/{operation}`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"`, an instance of `CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error400"` [400] no body · `"error503"` [503] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditRequest` (5):

| Field | Channel | Wire | Type | Req |
| --- | --- | --- | --- | --- |
| `tradeId` | `path` | — | `string` | yes |
| `leg` | `path` | — | `Leg` | yes |
| `operation` | `path` | — | `Operation` | yes |
| `xFabricWriteToken` | `header` | `X-Fabric-Write-Token` | `string` | yes |
| `body` | `body` | — | `ApiFabricTradesLegsOperationRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `Leg` | `legSchema` | `src/models/leg.ts` |
| `Operation` | `operationSchema` | `src/models/operation.ts` |
| `ApiFabricTradesLegsOperationRequest` | `apiFabricTradesLegsOperationRequestSchema` | `src/models/api-fabric-trades-legs-operation-request.ts` |

### createPayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuote

- **Signature**: `createPayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuote(request: CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteRequest, options?: RequestOptions): ApiPromise<undefined, CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError>`
- **Wire**: `POST /api/paypal/orders/create`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"`, an instance of `CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error409"` [409] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `ApiPaypalOrdersCreateRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiPaypalOrdersCreateRequest` | `apiPaypalOrdersCreateRequestSchema` | `src/models/api-paypal-orders-create-request.ts` |

### deprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCapture

- **Signature**: `deprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCapture(request: CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureRequest, options?: RequestOptions): ApiPromise<undefined, CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError>`
- **Wire**: `POST /trades/{id}/settle`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"`, an instance of `CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error409"` [409] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `id` | `path` | `string` | yes |

### dispatchZapierOutboundAutomationWebhook

- **Signature**: `dispatchZapierOutboundAutomationWebhook(request?: CorridorFlowCrossBorderTradePrototypeApiClient.DispatchZapierOutboundAutomationWebhookRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `POST /api/zapier/trigger`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field. **Optional**: omit it and the request carries no body and no `Content-Type` header at all
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.DispatchZapierOutboundAutomationWebhookRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `ApiZapierTriggerRequest` | no |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiZapierTriggerRequest` | `apiZapierTriggerRequestSchema` | `src/models/api-zapier-trigger-request.ts` |

### elasticObservabilityFinancialCrimeSearch

- **Signature**: `elasticObservabilityFinancialCrimeSearch(request?: CorridorFlowCrossBorderTradePrototypeApiClient.ElasticObservabilityFinancialCrimeSearchRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `GET /api/elastic/search`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.ElasticObservabilityFinancialCrimeSearchRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `q` | `query` | `string` | no |

### endTheCurrentDemoSession

- **Signature**: `endTheCurrentDemoSession(options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `POST /auth/logout`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

### getALocalSha256ReceiptDigestForADemoSettlement

- **Signature**: `getALocalSha256ReceiptDigestForADemoSettlement(request: CorridorFlowCrossBorderTradePrototypeApiClient.GetALocalSha256ReceiptDigestForADemoSettlementRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `GET /api/receipts/{tradeId}`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.GetALocalSha256ReceiptDigestForADemoSettlementRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `tradeId` | `path` | `string` | yes |

### getTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTrade

- **Signature**: `getTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTrade(request: CorridorFlowCrossBorderTradePrototypeApiClient.GetTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTradeRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `GET /api/paypal/orders/quote/{tradeId}`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.GetTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTradeRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `tradeId` | `path` | `string` | yes |

### getTheSignedInOperatorIdentityAndRole

- **Signature**: `getTheSignedInOperatorIdentityAndRole(options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `GET /me`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

### healthAndSystemStatus

- **Signature**: `healthAndSystemStatus(options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `GET /health`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

### listAllActiveAndSettledBilateralTrades

- **Signature**: `listAllActiveAndSettledBilateralTrades(options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `GET /trades`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

### marksTheSampleCounterpartyLegHeldInTheDemoWorkflow

- **Signature**: `marksTheSampleCounterpartyLegHeldInTheDemoWorkflow(request: CorridorFlowCrossBorderTradePrototypeApiClient.MarksTheSampleCounterpartyLegHeldInTheDemoWorkflowRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `POST /trades/{id}/accept`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.MarksTheSampleCounterpartyLegHeldInTheDemoWorkflowRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `id` | `path` | `string` | yes |

### proposeANewSampleTradeInTheDemoWorkflow

- **Signature**: `proposeANewSampleTradeInTheDemoWorkflow(request: CorridorFlowCrossBorderTradePrototypeApiClient.ProposeANewSampleTradeInTheDemoWorkflowRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `POST /trades`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.ProposeANewSampleTradeInTheDemoWorkflowRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `TradesRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `TradesRequest` | `tradesRequestSchema` | `src/models/trades-request.ts` |

### readALiveFabricChaincodeSnapshot

- **Signature**: `readALiveFabricChaincodeSnapshot(options?: RequestOptions): ApiPromise<undefined, CorridorFlowCrossBorderTradePrototypeApiClient.ReadALiveFabricChaincodeSnapshotError>`
- **Wire**: `GET /api/fabric/ledger`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"`, an instance of `CorridorFlowCrossBorderTradePrototypeApiClient.ReadALiveFabricChaincodeSnapshotError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error503"` [503] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

### retryAFailedPayPalBatchPayoutV1ForASettledDemoTrade

- **Signature**: `retryAFailedPayPalBatchPayoutV1ForASettledDemoTrade(request: CorridorFlowCrossBorderTradePrototypeApiClient.RetryAFailedPayPalBatchPayoutV1ForASettledDemoTradeRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `POST /api/paypal/payouts/batch`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.RetryAFailedPayPalBatchPayoutV1ForASettledDemoTradeRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `ApiPaypalPayoutsBatchRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiPaypalPayoutsBatchRequest` | `apiPaypalPayoutsBatchRequestSchema` | `src/models/api-paypal-payouts-batch-request.ts` |

### runDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanation

- **Signature**: `runDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanation(request?: CorridorFlowCrossBorderTradePrototypeApiClient.RunDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanationRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `POST /api/ai/risk-screen`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field. **Optional**: omit it and the request carries no body and no `Content-Type` header at all
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.RunDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanationRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `ApiAiRiskScreenRequest` | no |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiAiRiskScreenRequest` | `apiAiRiskScreenRequestSchema` | `src/models/api-ai-risk-screen-request.ts` |

### searchChannel3B2BProductCatalog

- **Signature**: `searchChannel3B2BProductCatalog(request?: CorridorFlowCrossBorderTradePrototypeApiClient.SearchChannel3B2BProductCatalogRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `GET /api/channel3/catalog`
- **Auth**: `bearerAuth`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.SearchChannel3B2BProductCatalogRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `q` | `query` | `string` | no |

### settleAnAcceptedFabricTrade

- **Signature**: `settleAnAcceptedFabricTrade(request: CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeRequest, options?: RequestOptions): ApiPromise<undefined, CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeError>`
- **Wire**: `POST /api/fabric/trades/{tradeId}/settle`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"`, an instance of `CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error400"` [400] no body · `"error503"` [503] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeRequest` (3):

| Field | Channel | Wire | Type | Req |
| --- | --- | --- | --- | --- |
| `tradeId` | `path` | — | `string` | yes |
| `xFabricWriteToken` | `header` | `X-Fabric-Write-Token` | `string` | yes |
| `body` | `body` | — | `ApiFabricTradesSettleRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiFabricTradesSettleRequest` | `apiFabricTradesSettleRequestSchema` | `src/models/api-fabric-trades-settle-request.ts` |

### signInToAConfiguredDemoRole

- **Signature**: `signInToAConfiguredDemoRole(request: CorridorFlowCrossBorderTradePrototypeApiClient.SignInToAConfiguredDemoRoleRequest, options?: RequestOptions): ApiPromise<undefined, ApiError>`
- **Wire**: `POST /auth/login`
- **Auth**: none — public; no credential is sent
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.SignInToAConfiguredDemoRoleRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `AuthLoginRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `AuthLoginRequest` | `authLoginRequestSchema` | `src/models/auth-login-request.ts` |

### submitANewInrSgdTradeProposalToFabric

- **Signature**: `submitANewInrSgdTradeProposalToFabric(request: CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricRequest, options?: RequestOptions): ApiPromise<undefined, CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricError>`
- **Wire**: `POST /api/fabric/trades/propose`
- **Auth**: `bearerAuth`
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `CorridorFlowCrossBorderTradePrototypeApiError` with `kind: "api"`, an instance of `CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error400"` [400] no body · `"error503"` [503] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricRequest` (2):

| Field | Channel | Wire | Type | Req |
| --- | --- | --- | --- | --- |
| `xFabricWriteToken` | `header` | `X-Fabric-Write-Token` | `string` | yes |
| `body` | `body` | — | `ApiFabricTradesProposeRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiFabricTradesProposeRequest` | `apiFabricTradesProposeRequestSchema` | `src/models/api-fabric-trades-propose-request.ts` |


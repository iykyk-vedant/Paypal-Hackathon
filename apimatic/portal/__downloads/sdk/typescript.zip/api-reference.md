# Reference

> Source: [CorridorFlowCrossBorderTradePrototypeApiClient](src/client.ts)

<details>
<summary><code>acceptAFabricTradeProposalAsTheCounterpartyBank(request: CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankRequest, options?: RequestOptions): ApiPromise&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.acceptAFabricTradeProposalAsTheCounterpartyBank({
    tradeId: "some example string",
    xFabricWriteToken: "some example string",
  });
} catch (err) {
  // TODO: Handle 'err' of type CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .acceptAFabricTradeProposalAsTheCounterpartyBank({
    tradeId: "some example string",
    xFabricWriteToken: "some example string",
  })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>tradeId</code> | <code>string</code> | - |
| <code>xFabricWriteToken</code> | <code>string</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.acceptAFabricTradeProposalAsTheCounterpartyBank(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankError](src/client.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.acceptAFabricTradeProposalAsTheCounterpartyBank(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>calculateIndicativeDemoQuoteWithOptionalGeminiExplanation(request?: CorridorFlowCrossBorderTradePrototypeApiClient.CalculateIndicativeDemoQuoteWithOptionalGeminiExplanationRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.calculateIndicativeDemoQuoteWithOptionalGeminiExplanation();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.calculateIndicativeDemoQuoteWithOptionalGeminiExplanation().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body?</code> | <code>[ApiAiNegotiateRequest](src/models/api-ai-negotiate-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.calculateIndicativeDemoQuoteWithOptionalGeminiExplanation(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.calculateIndicativeDemoQuoteWithOptionalGeminiExplanation(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>capturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedger(request: CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerRequest, options?: RequestOptions): ApiPromise&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.capturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedger({
    id: "some example string",
    body: { tradeId: "some example string" },
  });
} catch (err) {
  // TODO: Handle 'err' of type CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .capturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedger({
    id: "some example string",
    body: { tradeId: "some example string" },
  })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id</code> | <code>string</code> | - |
| <code>body</code> | <code>[ApiPaypalOrdersCaptureRequest](src/models/api-paypal-orders-capture-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.capturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedger(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError](src/client.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.capturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedger(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>checkFabricGatewayQueryConnectivity(options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Reports a live read-only chaincode query probe when Gateway mode is enabled; TCP reachability alone is not treated as a Fabric connection.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.checkFabricGatewayQueryConnectivity();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.checkFabricGatewayQueryConnectivity().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.checkFabricGatewayQueryConnectivity()`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.checkFabricGatewayQueryConnectivity().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>commitOneFabricSettlementLegDebitOrPayeeCredit(request: CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditRequest, options?: RequestOptions): ApiPromise&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires explicit settlement confirmation, a settled trade, and the signing identity for the payer or payee bank. Each call commits a separate ledger transaction.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.commitOneFabricSettlementLegDebitOrPayeeCredit({
    tradeId: "some example string",
    leg: Leg.A,
    operation: Operation.Debit,
    xFabricWriteToken: "some example string",
    body: {},
  });
} catch (err) {
  // TODO: Handle 'err' of type CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .commitOneFabricSettlementLegDebitOrPayeeCredit({
    tradeId: "some example string",
    leg: Leg.A,
    operation: Operation.Debit,
    xFabricWriteToken: "some example string",
    body: {},
  })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>tradeId</code> | <code>string</code> | - |
| <code>leg</code> | <code>[Leg](src/models/leg.ts)</code> | - |
| <code>operation</code> | <code>[Operation](src/models/operation.ts)</code> | - |
| <code>xFabricWriteToken</code> | <code>string</code> | - |
| <code>body</code> | <code>[ApiFabricTradesLegsOperationRequest](src/models/api-fabric-trades-legs-operation-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.commitOneFabricSettlementLegDebitOrPayeeCredit(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditError](src/client.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.commitOneFabricSettlementLegDebitOrPayeeCredit(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>createPayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuote(request: CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteRequest, options?: RequestOptions): ApiPromise&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.createPayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuote({ body: {} });
} catch (err) {
  // TODO: Handle 'err' of type CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .createPayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuote({ body: {} })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiPaypalOrdersCreateRequest](src/models/api-paypal-orders-create-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.createPayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuote(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError](src/client.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.createPayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuote(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>deprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCapture(request: CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureRequest, options?: RequestOptions): ApiPromise&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.deprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCapture({
    id: "some example string",
  });
} catch (err) {
  // TODO: Handle 'err' of type CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .deprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCapture({ id: "some example string" })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id</code> | <code>string</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.deprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCapture(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError](src/client.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.deprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCapture(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>dispatchZapierOutboundAutomationWebhook(request?: CorridorFlowCrossBorderTradePrototypeApiClient.DispatchZapierOutboundAutomationWebhookRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.dispatchZapierOutboundAutomationWebhook();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.dispatchZapierOutboundAutomationWebhook().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body?</code> | <code>[ApiZapierTriggerRequest](src/models/api-zapier-trigger-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.dispatchZapierOutboundAutomationWebhook(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.dispatchZapierOutboundAutomationWebhook(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>elasticObservabilityFinancialCrimeSearch(request?: CorridorFlowCrossBorderTradePrototypeApiClient.ElasticObservabilityFinancialCrimeSearchRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.elasticObservabilityFinancialCrimeSearch();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.elasticObservabilityFinancialCrimeSearch().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>q?</code> | <code>string</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.elasticObservabilityFinancialCrimeSearch(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.elasticObservabilityFinancialCrimeSearch(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>endTheCurrentDemoSession(options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.endTheCurrentDemoSession();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.endTheCurrentDemoSession().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.endTheCurrentDemoSession()`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.endTheCurrentDemoSession().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>getALocalSha256ReceiptDigestForADemoSettlement(request: CorridorFlowCrossBorderTradePrototypeApiClient.GetALocalSha256ReceiptDigestForADemoSettlementRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.getALocalSha256ReceiptDigestForADemoSettlement({ tradeId: "some example string" });
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .getALocalSha256ReceiptDigestForADemoSettlement({ tradeId: "some example string" })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>tradeId</code> | <code>string</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.getALocalSha256ReceiptDigestForADemoSettlement(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.getALocalSha256ReceiptDigestForADemoSettlement(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>getTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTrade(request: CorridorFlowCrossBorderTradePrototypeApiClient.GetTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTradeRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.getTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTrade({ tradeId: "some example string" });
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .getTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTrade({ tradeId: "some example string" })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>tradeId</code> | <code>string</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.getTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTrade(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.getTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTrade(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>getTheSignedInOperatorIdentityAndRole(options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.getTheSignedInOperatorIdentityAndRole();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.getTheSignedInOperatorIdentityAndRole().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.getTheSignedInOperatorIdentityAndRole()`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.getTheSignedInOperatorIdentityAndRole().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>healthAndSystemStatus(options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.healthAndSystemStatus();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.healthAndSystemStatus().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.healthAndSystemStatus()`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.healthAndSystemStatus().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>listAllActiveAndSettledBilateralTrades(options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.listAllActiveAndSettledBilateralTrades();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.listAllActiveAndSettledBilateralTrades().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.listAllActiveAndSettledBilateralTrades()`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.listAllActiveAndSettledBilateralTrades().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>marksTheSampleCounterpartyLegHeldInTheDemoWorkflow(request: CorridorFlowCrossBorderTradePrototypeApiClient.MarksTheSampleCounterpartyLegHeldInTheDemoWorkflowRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.marksTheSampleCounterpartyLegHeldInTheDemoWorkflow({ id: "some example string" });
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .marksTheSampleCounterpartyLegHeldInTheDemoWorkflow({ id: "some example string" })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id</code> | <code>string</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.marksTheSampleCounterpartyLegHeldInTheDemoWorkflow(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.marksTheSampleCounterpartyLegHeldInTheDemoWorkflow(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>proposeANewSampleTradeInTheDemoWorkflow(request: CorridorFlowCrossBorderTradePrototypeApiClient.ProposeANewSampleTradeInTheDemoWorkflowRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.proposeANewSampleTradeInTheDemoWorkflow({ body: {} });
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.proposeANewSampleTradeInTheDemoWorkflow({ body: {} }).asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[TradesRequest](src/models/trades-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.proposeANewSampleTradeInTheDemoWorkflow(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.proposeANewSampleTradeInTheDemoWorkflow(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>readALiveFabricChaincodeSnapshot(options?: RequestOptions): ApiPromise&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.ReadALiveFabricChaincodeSnapshotError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires a configured Fabric Gateway identity. Evaluates chaincode queries only and never submits a transaction. Private account queries may be denied by chaincode access rules.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.readALiveFabricChaincodeSnapshot();
} catch (err) {
  // TODO: Handle 'err' of type CorridorFlowCrossBorderTradePrototypeApiClient.ReadALiveFabricChaincodeSnapshotError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.readALiveFabricChaincodeSnapshot().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.readALiveFabricChaincodeSnapshot()`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[CorridorFlowCrossBorderTradePrototypeApiClient.ReadALiveFabricChaincodeSnapshotError](src/client.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.readALiveFabricChaincodeSnapshot().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.ReadALiveFabricChaincodeSnapshotError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>retryAFailedPayPalBatchPayoutV1ForASettledDemoTrade(request: CorridorFlowCrossBorderTradePrototypeApiClient.RetryAFailedPayPalBatchPayoutV1ForASettledDemoTradeRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.retryAFailedPayPalBatchPayoutV1ForASettledDemoTrade({ body: {} });
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.retryAFailedPayPalBatchPayoutV1ForASettledDemoTrade({ body: {} }).asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiPaypalPayoutsBatchRequest](src/models/api-paypal-payouts-batch-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.retryAFailedPayPalBatchPayoutV1ForASettledDemoTrade(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.retryAFailedPayPalBatchPayoutV1ForASettledDemoTrade(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>runDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanation(request?: CorridorFlowCrossBorderTradePrototypeApiClient.RunDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanationRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.runDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanation();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .runDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanation()
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body?</code> | <code>[ApiAiRiskScreenRequest](src/models/api-ai-risk-screen-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.runDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanation(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.runDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanation(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>searchChannel3B2BProductCatalog(request?: CorridorFlowCrossBorderTradePrototypeApiClient.SearchChannel3B2BProductCatalogRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.searchChannel3B2BProductCatalog();
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.searchChannel3B2BProductCatalog().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>q?</code> | <code>string</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.searchChannel3B2BProductCatalog(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.searchChannel3B2BProductCatalog(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>settleAnAcceptedFabricTrade(request: CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeRequest, options?: RequestOptions): ApiPromise&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires explicit confirmation in the request and RegAMSP plus RegBMSP peer endorsements. It does not verify PayPal capture.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.settleAnAcceptedFabricTrade({
    tradeId: "some example string",
    xFabricWriteToken: "some example string",
    body: {},
  });
} catch (err) {
  // TODO: Handle 'err' of type CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .settleAnAcceptedFabricTrade({
    tradeId: "some example string",
    xFabricWriteToken: "some example string",
    body: {},
  })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>tradeId</code> | <code>string</code> | - |
| <code>xFabricWriteToken</code> | <code>string</code> | - |
| <code>body</code> | <code>[ApiFabricTradesSettleRequest](src/models/api-fabric-trades-settle-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.settleAnAcceptedFabricTrade(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeError](src/client.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.settleAnAcceptedFabricTrade(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>signInToAConfiguredDemoRole(request: CorridorFlowCrossBorderTradePrototypeApiClient.SignInToAConfiguredDemoRoleRequest, options?: RequestOptions): ApiPromise&lt;undefined, ApiError&gt;</code></summary>

<dl>
<dd>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.signInToAConfiguredDemoRole({
    body: { operator: "some example string", password: "some example password" },
  });
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .signInToAConfiguredDemoRole({
    body: { operator: "some example string", password: "some example password" },
  })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[AuthLoginRequest](src/models/auth-login-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.signInToAConfiguredDemoRole(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.signInToAConfiguredDemoRole(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, ApiError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>submitANewInrSgdTradeProposalToFabric(request: CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricRequest, options?: RequestOptions): ApiPromise&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires the Fabric write feature flag and a rotated signing identity. Private trade details and salt are sent as transient proposal data; this writes to the permanent test ledger.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.submitANewInrSgdTradeProposalToFabric({
    xFabricWriteToken: "some example string",
    body: {
      proposerMsp: ProposerMsp.BankA1Msp,
      ccyA: CcyA.Inr,
      amountA: "some example string",
      ccyB: CcyB.Inr,
      amountB: "some example string",
    },
  });
} catch (err) {
  // TODO: Handle 'err' of type CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client
  .submitANewInrSgdTradeProposalToFabric({
    xFabricWriteToken: "some example string",
    body: {
      proposerMsp: ProposerMsp.BankA1Msp,
      ccyA: CcyA.Inr,
      amountA: "some example string",
      ccyB: CcyB.Inr,
      amountB: "some example string",
    },
  })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>xFabricWriteToken</code> | <code>string</code> | - |
| <code>body</code> | <code>[ApiFabricTradesProposeRequest](src/models/api-fabric-trades-propose-request.ts)</code> | - |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.submitANewInrSgdTradeProposalToFabric(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricError](src/client.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.submitANewInrSgdTradeProposalToFabric(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[CorridorFlowCrossBorderTradePrototypeApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>


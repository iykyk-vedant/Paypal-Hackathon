import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

export type TradesRequest = {
  proposer?: string;
  cparty?: string;
  ccyA?: string;
  amountA?: number;
  ccyB?: string;
  amountB?: number;
  fxRate?: string;
  reference?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const tradesRequestSchema: Schema<TradesRequest> = s.object<TradesRequest>(
  {
    proposer: s.optional(s.string()),
    cparty: s.optional(s.string()),
    ccyA: s.optional(s.string()),
    amountA: s.optional(s.float64()),
    ccyB: s.optional(s.string()),
    amountB: s.optional(s.float64()),
    fxRate: s.optional(s.string()),
    reference: s.optional(s.string()),
  },
  { additionalProperties: s.json() },
);

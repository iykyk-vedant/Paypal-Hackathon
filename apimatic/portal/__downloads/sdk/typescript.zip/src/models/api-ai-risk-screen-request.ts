import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

export type ApiAiRiskScreenRequest = {
  tradeId?: string;
  amountA?: string;
  currencyA?: string;
  amountB?: string;
  currencyB?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiAiRiskScreenRequestSchema: Schema<ApiAiRiskScreenRequest> = s.object<ApiAiRiskScreenRequest>(
  {
    tradeId: s.optional(s.string()),
    amountA: s.optional(s.string()),
    currencyA: s.optional(s.string()),
    amountB: s.optional(s.string()),
    currencyB: s.optional(s.string()),
  },
  { additionalProperties: s.json() },
);

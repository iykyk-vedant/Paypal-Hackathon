import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

export type ApiFabricTradesSettleRequest = {
  /** @default "True" */
  confirmSettlement?: "True";
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiFabricTradesSettleRequestSchema: Schema<ApiFabricTradesSettleRequest> =
  s.object<ApiFabricTradesSettleRequest>(
    {
      confirmSettlement: s.defaulted(s.literal("True"), "True"),
    },
    { additionalProperties: s.json() },
  );

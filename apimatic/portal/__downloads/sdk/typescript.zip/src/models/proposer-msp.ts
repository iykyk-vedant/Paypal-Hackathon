import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

export const ProposerMsp = {
  BankA1Msp: "BankA1MSP",
  BankB1Msp: "BankB1MSP",
} as const;
export type ProposerMsp = (typeof ProposerMsp)[keyof typeof ProposerMsp] | (string & {});

export const proposerMspSchema: EnumSchema<ProposerMsp> = s.enumOf<ProposerMsp>(ProposerMsp);

import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

export type ApiPaypalPayoutsBatchRequest = {
  tradeId?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiPaypalPayoutsBatchRequestSchema: Schema<ApiPaypalPayoutsBatchRequest> =
  s.object<ApiPaypalPayoutsBatchRequest>(
    {
      tradeId: s.optional(s.string()),
    },
    { additionalProperties: s.json() },
  );

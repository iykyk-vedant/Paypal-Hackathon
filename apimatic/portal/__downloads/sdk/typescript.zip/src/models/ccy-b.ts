import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

export const CcyB = {
  Inr: "INR",
  Sgd: "SGD",
} as const;
export type CcyB = (typeof CcyB)[keyof typeof CcyB] | (string & {});

export const ccyBSchema: EnumSchema<CcyB> = s.enumOf<CcyB>(CcyB);

import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

export type ApiAiNegotiateRequest = {
  buyerOrg?: string;
  sellerOrg?: string;
  currencyFrom?: string;
  currencyTo?: string;
  amountFrom?: number;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiAiNegotiateRequestSchema: Schema<ApiAiNegotiateRequest> = s.object<ApiAiNegotiateRequest>(
  {
    buyerOrg: s.optional(s.string()),
    sellerOrg: s.optional(s.string()),
    currencyFrom: s.optional(s.string()),
    currencyTo: s.optional(s.string()),
    amountFrom: s.optional(s.float64()),
  },
  { additionalProperties: s.json() },
);

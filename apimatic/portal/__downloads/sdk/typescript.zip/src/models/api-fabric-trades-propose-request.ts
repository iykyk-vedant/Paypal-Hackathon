import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { ccyASchema, type CcyA } from "./ccy-a.js";
import { ccyBSchema, type CcyB } from "./ccy-b.js";
import { proposerMspSchema, type ProposerMsp } from "./proposer-msp.js";

export type ApiFabricTradesProposeRequest = {
  proposerMsp: ProposerMsp;
  ccyA: CcyA;
  /** Positive currency minor units */
  amountA: string;
  ccyB: CcyB;
  /** Positive currency minor units */
  amountB: string;
  reference?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiFabricTradesProposeRequestSchema: Schema<ApiFabricTradesProposeRequest> =
  s.object<ApiFabricTradesProposeRequest>(
    {
      proposerMsp: proposerMspSchema,
      ccyA: ccyASchema,
      amountA: s.string(),
      ccyB: ccyBSchema,
      amountB: s.string(),
      reference: s.optional(s.string()),
    },
    { additionalProperties: s.json() },
  );

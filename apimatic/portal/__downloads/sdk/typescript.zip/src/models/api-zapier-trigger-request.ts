import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

export type ApiZapierTriggerRequest = {
  eventType?: string;
  payload?: Record<string, unknown>;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiZapierTriggerRequestSchema: Schema<ApiZapierTriggerRequest> =
  s.object<ApiZapierTriggerRequest>(
    {
      eventType: s.optional(s.string()),
      payload: s.optional(s.record(s.string(), s.unknown())),
    },
    { additionalProperties: s.json() },
  );

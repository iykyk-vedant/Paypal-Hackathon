import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

export const Leg = {
  A: "A",
  B: "B",
} as const;
export type Leg = (typeof Leg)[keyof typeof Leg] | (string & {});

export const legSchema: EnumSchema<Leg> = s.enumOf<Leg>(Leg);

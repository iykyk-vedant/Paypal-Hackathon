import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

export type AuthLoginRequest = {
  operator: string;
  password: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const authLoginRequestSchema: Schema<AuthLoginRequest> = s.object<AuthLoginRequest>(
  {
    operator: s.string(),
    password: s.string(),
  },
  { additionalProperties: s.json() },
);

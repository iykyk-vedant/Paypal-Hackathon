import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

export type ApiPaypalOrdersCaptureRequest = {
  tradeId: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiPaypalOrdersCaptureRequestSchema: Schema<ApiPaypalOrdersCaptureRequest> =
  s.object<ApiPaypalOrdersCaptureRequest>(
    {
      tradeId: s.string(),
    },
    { additionalProperties: s.json() },
  );

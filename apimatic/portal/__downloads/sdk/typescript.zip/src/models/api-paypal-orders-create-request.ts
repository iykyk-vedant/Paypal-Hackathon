import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

export type ApiPaypalOrdersCreateRequest = {
  tradeId?: string;
  description?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiPaypalOrdersCreateRequestSchema: Schema<ApiPaypalOrdersCreateRequest> =
  s.object<ApiPaypalOrdersCreateRequest>(
    {
      tradeId: s.optional(s.string()),
      description: s.optional(s.string()),
    },
    { additionalProperties: s.json() },
  );

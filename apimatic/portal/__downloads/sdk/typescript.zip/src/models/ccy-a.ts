import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

export const CcyA = {
  Inr: "INR",
  Sgd: "SGD",
} as const;
export type CcyA = (typeof CcyA)[keyof typeof CcyA] | (string & {});

export const ccyASchema: EnumSchema<CcyA> = s.enumOf<CcyA>(CcyA);

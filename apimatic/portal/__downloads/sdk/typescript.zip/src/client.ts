import { buildAuthSchemes, type AuthSchemes } from "./auth-schemes.js";
import type { ClientOptions } from "./client-options.js";
import { ApiError, type Declared, type Undeclared } from "./core/api-error.js";
import type { ApiPromise } from "./core/api-promise.js";
import type { RequestOptions } from "./core/api-request.js";
import { noneAuth } from "./core/auth/schemes.js";
import { buildCoreClientOptions } from "./core/client-options.js";
import { RawClient } from "./core/raw-client.js";
import type { ErrorDecoders } from "./core/response-decoder.js";
import * as host from "./core/runtime-environment.js";
import { uuid } from "./core/uuid.js";
import * as s from "./core/validation/index.js";
import {
  apiAiNegotiateRequestSchema,
  type ApiAiNegotiateRequest,
} from "./models/api-ai-negotiate-request.js";
import {
  apiAiRiskScreenRequestSchema,
  type ApiAiRiskScreenRequest,
} from "./models/api-ai-risk-screen-request.js";
import {
  apiFabricTradesLegsOperationRequestSchema,
  type ApiFabricTradesLegsOperationRequest,
} from "./models/api-fabric-trades-legs-operation-request.js";
import {
  apiFabricTradesProposeRequestSchema,
  type ApiFabricTradesProposeRequest,
} from "./models/api-fabric-trades-propose-request.js";
import {
  apiFabricTradesSettleRequestSchema,
  type ApiFabricTradesSettleRequest,
} from "./models/api-fabric-trades-settle-request.js";
import {
  apiPaypalOrdersCaptureRequestSchema,
  type ApiPaypalOrdersCaptureRequest,
} from "./models/api-paypal-orders-capture-request.js";
import {
  apiPaypalOrdersCreateRequestSchema,
  type ApiPaypalOrdersCreateRequest,
} from "./models/api-paypal-orders-create-request.js";
import {
  apiPaypalPayoutsBatchRequestSchema,
  type ApiPaypalPayoutsBatchRequest,
} from "./models/api-paypal-payouts-batch-request.js";
import {
  apiZapierTriggerRequestSchema,
  type ApiZapierTriggerRequest,
} from "./models/api-zapier-trigger-request.js";
import { authLoginRequestSchema, type AuthLoginRequest } from "./models/auth-login-request.js";
import { legSchema, type Leg } from "./models/leg.js";
import { operationSchema, type Operation } from "./models/operation.js";
import { tradesRequestSchema, type TradesRequest } from "./models/trades-request.js";
import { buildServers, type Servers } from "./servers.js";

/**
 * Hackathon prototype API for the CorridorFlow web demo, combining a PostgreSQL-backed demo trade
 * workflow, deterministic corridor rules, optional Gemini explanations, and PayPal Developer
 * Platform (Orders v2, Payouts v1) Sandbox or simulation. Password-protected demo roles use
 * expiring bearer sessions stored in PostgreSQL when configured. This prototype access layer is not
 * a production identity system.
 */
export class CorridorFlowCrossBorderTradePrototypeApiClient {
  readonly #rawClient: RawClient;
  readonly #servers: Servers;
  readonly #auth: AuthSchemes;

  constructor(options: ClientOptions = {}) {
    this.#rawClient = new RawClient({
      ...buildCoreClientOptions(options, "CORRIDOR_FLOW_CROSS_BORDER_TRADE_PROTOTYPE_API_CLIENT_LOG"),
      defaultHeaders: [
        {
          name: "User-Agent",
          value: "CorridorFlowCrossBorderTradePrototypeApiClient/1.0.0 TypeScript",
          schema: s.string(),
        },
        { name: "X-APIMatic-Lang", value: "TypeScript", schema: s.string() },
        { name: "X-APIMatic-Package-Version", value: "1.0.0", schema: s.string() },
        { name: "X-APIMatic-Gen-Version", value: "4.0.0", schema: s.string() },
        { name: "X-APIMatic-OS", value: host.operatingSystem(), schema: s.optional(s.string()) },
        { name: "X-APIMatic-Runtime", value: host.runtimeDescription(), schema: s.optional(s.string()) },
      ],
      defaultQuery: [],
      defaultPathParams: [],
    });

    this.#servers = buildServers(options);

    this.#auth = buildAuthSchemes(options);
  }

  /**
   * Accept a Fabric trade proposal as the counterparty bank
   *
   * @returns Fabric transaction committed and validated
   *
   * @throws {@link
   * CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankError}
   * when the API answers with an error status — narrow on `err.payload.kind`
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  acceptAFabricTradeProposalAsTheCounterpartyBank(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankRequest,
    options?: RequestOptions,
  ): ApiPromise<
    undefined,
    CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankError
  > {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/fabric/trades/{tradeId}/accept"),
        auth: this.#auth.bearerAuth,
        pathParams: [{ name: "tradeId", value: request.tradeId, schema: s.string() }],
        query: [],
        headers: [
          { name: "X-Fabric-Write-Token", value: request.xFabricWriteToken, schema: s.string() },
          { name: "Idempotency-Key", value: uuid(), schema: s.string() },
        ],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory:
          CorridorFlowCrossBorderTradePrototypeApiClient.AcceptAFabricTradeProposalAsTheCounterpartyBankError,
      },
      options,
    );
  }

  /**
   * Calculate indicative demo quote with optional Gemini explanation
   *
   * @returns Indicative demo trade proposal (static FX benchmark and volume heuristic)
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  calculateIndicativeDemoQuoteWithOptionalGeminiExplanation(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.CalculateIndicativeDemoQuoteWithOptionalGeminiExplanationRequest = {},
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/ai/negotiate"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: {
          kind: "json",
          value: request.body,
          schema: s.optional(s.lazy(() => apiAiNegotiateRequestSchema)),
        },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Capture PayPal Order, verify USD amount against quote, and update demo ledger
   *
   * @returns Capture and local demo settlement details
   *
   * @throws {@link
   * CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError}
   * when the API answers with an error status — narrow on `err.payload.kind`
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  capturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedger(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerRequest,
    options?: RequestOptions,
  ): ApiPromise<
    undefined,
    CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError
  > {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/paypal/orders/{id}/capture"),
        auth: this.#auth.bearerAuth,
        pathParams: [{ name: "id", value: request.id, schema: s.string() }],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: apiPaypalOrdersCaptureRequestSchema },
      },
      {
        success: { kind: "empty" },
        errorFactory:
          CorridorFlowCrossBorderTradePrototypeApiClient.CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError,
      },
      options,
    );
  }

  /**
   * Check Fabric Gateway query connectivity
   *
   * @remarks
   * Reports a live read-only chaincode query probe when Gateway mode is enabled; TCP reachability
   * alone is not treated as a Fabric connection.
   *
   * @returns Gateway status and demo or live ledger source
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  checkFabricGatewayQueryConnectivity(options?: RequestOptions): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/fabric/status"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Commit one Fabric settlement-leg debit or payee credit
   *
   * @remarks
   * Requires explicit settlement confirmation, a settled trade, and the signing identity for the
   * payer or payee bank. Each call commits a separate ledger transaction.
   *
   * @returns Fabric transaction committed and validated
   *
   * @throws {@link
   * CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditError}
   * when the API answers with an error status — narrow on `err.payload.kind`
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  commitOneFabricSettlementLegDebitOrPayeeCredit(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditRequest,
    options?: RequestOptions,
  ): ApiPromise<
    undefined,
    CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditError
  > {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/fabric/trades/{tradeId}/legs/{leg}/{operation}"),
        auth: this.#auth.bearerAuth,
        pathParams: [
          { name: "tradeId", value: request.tradeId, schema: s.string() },
          { name: "leg", value: request.leg, schema: legSchema },
          { name: "operation", value: request.operation, schema: operationSchema },
        ],
        query: [],
        headers: [
          { name: "X-Fabric-Write-Token", value: request.xFabricWriteToken, schema: s.string() },
          { name: "Idempotency-Key", value: uuid(), schema: s.string() },
        ],
        body: { kind: "json", value: request.body, schema: apiFabricTradesLegsOperationRequestSchema },
      },
      {
        success: { kind: "empty" },
        errorFactory:
          CorridorFlowCrossBorderTradePrototypeApiClient.CommitOneFabricSettlementLegDebitOrPayeeCreditError,
      },
      options,
    );
  }

  /**
   * Create PayPal Orders v2 Order (Sandbox or simulation) using server-calculated USD quote
   *
   * @returns PayPal Order response with server USD funding quote
   *
   * @throws {@link
   * CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError}
   * when the API answers with an error status — narrow on `err.payload.kind`
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  createPayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuote(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteRequest,
    options?: RequestOptions,
  ): ApiPromise<
    undefined,
    CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError
  > {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/paypal/orders/create"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: apiPaypalOrdersCreateRequestSchema },
      },
      {
        success: { kind: "empty" },
        errorFactory:
          CorridorFlowCrossBorderTradePrototypeApiClient.CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError,
      },
      options,
    );
  }

  /**
   * Deprecated direct settle endpoint (returns 409; capture via /api/paypal/orders/{id}/capture)
   *
   * @throws {@link
   * CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError}
   * when the API answers with an error status — narrow on `err.payload.kind`
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  deprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCapture(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureRequest,
    options?: RequestOptions,
  ): ApiPromise<
    undefined,
    CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError
  > {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/trades/{id}/settle"),
        auth: this.#auth.bearerAuth,
        pathParams: [{ name: "id", value: request.id, schema: s.string() }],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory:
          CorridorFlowCrossBorderTradePrototypeApiClient.DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError,
      },
      options,
    );
  }

  /**
   * Dispatch Zapier Outbound Automation Webhook
   *
   * @returns Zapier delivery status
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  dispatchZapierOutboundAutomationWebhook(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.DispatchZapierOutboundAutomationWebhookRequest = {},
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/zapier/trigger"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: {
          kind: "json",
          value: request.body,
          schema: s.optional(s.lazy(() => apiZapierTriggerRequestSchema)),
        },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Elastic Observability & Financial Crime Search
   *
   * @returns Elastic search hits and query latency
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  elasticObservabilityFinancialCrimeSearch(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.ElasticObservabilityFinancialCrimeSearchRequest = {},
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/elastic/search"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [{ name: "q", value: request.q, schema: s.optional(s.string()) }],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * End the current demo session
   *
   * @returns Session revoked
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  endTheCurrentDemoSession(options?: RequestOptions): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/auth/logout"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Get a local SHA-256 receipt digest for a demo settlement
   *
   * @returns Local demo digest; not proof of Fabric, regulator approval, or external payment
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  getALocalSha256ReceiptDigestForADemoSettlement(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.GetALocalSha256ReceiptDigestForADemoSettlementRequest,
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/receipts/{tradeId}"),
        auth: this.#auth.bearerAuth,
        pathParams: [{ name: "tradeId", value: request.tradeId, schema: s.string() }],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Get the illustrative USD funding quote for an accepted demo trade
   *
   * @returns Static demo FX quote; not a live market rate
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  getTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTrade(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.GetTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTradeRequest,
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/paypal/orders/quote/{tradeId}"),
        auth: this.#auth.bearerAuth,
        pathParams: [{ name: "tradeId", value: request.tradeId, schema: s.string() }],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Get the signed-in operator identity and role
   *
   * @returns Active identity profile
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  getTheSignedInOperatorIdentityAndRole(options?: RequestOptions): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/me"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Health and System Status
   *
   * @returns System operational status
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  healthAndSystemStatus(options?: RequestOptions): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/health"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * List all active and settled bilateral trades
   *
   * @returns Array of trade composites
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  listAllActiveAndSettledBilateralTrades(options?: RequestOptions): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/trades"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Marks the sample counterparty leg held in the demo workflow
   *
   * @returns Accepted trade
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  marksTheSampleCounterpartyLegHeldInTheDemoWorkflow(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.MarksTheSampleCounterpartyLegHeldInTheDemoWorkflowRequest,
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/trades/{id}/accept"),
        auth: this.#auth.bearerAuth,
        pathParams: [{ name: "id", value: request.id, schema: s.string() }],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Propose a new sample trade in the demo workflow
   *
   * @returns Proposed trade record
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  proposeANewSampleTradeInTheDemoWorkflow(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.ProposeANewSampleTradeInTheDemoWorkflowRequest,
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/trades"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: tradesRequestSchema },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Read a live Fabric chaincode snapshot
   *
   * @remarks
   * Requires a configured Fabric Gateway identity. Evaluates chaincode queries only and never
   * submits a transaction. Private account queries may be denied by chaincode access rules.
   *
   * @returns Results and per-query errors from read-only chaincode evaluations
   *
   * @throws {@link
   * CorridorFlowCrossBorderTradePrototypeApiClient.ReadALiveFabricChaincodeSnapshotError} when the
   * API answers with an error status — narrow on `err.payload.kind`
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  readALiveFabricChaincodeSnapshot(
    options?: RequestOptions,
  ): ApiPromise<
    undefined,
    CorridorFlowCrossBorderTradePrototypeApiClient.ReadALiveFabricChaincodeSnapshotError
  > {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/fabric/ledger"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: CorridorFlowCrossBorderTradePrototypeApiClient.ReadALiveFabricChaincodeSnapshotError,
      },
      options,
    );
  }

  /**
   * Retry a failed PayPal Batch Payout v1 for a settled demo trade
   *
   * @returns Payout batch response
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  retryAFailedPayPalBatchPayoutV1ForASettledDemoTrade(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.RetryAFailedPayPalBatchPayoutV1ForASettledDemoTradeRequest,
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/paypal/payouts/batch"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: apiPaypalPayoutsBatchRequestSchema },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Run deterministic sample corridor & blocklist checks with optional Gemini explanation
   *
   * @returns Risk score and pass/refuse verdict
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  runDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanation(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.RunDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanationRequest = {},
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/ai/risk-screen"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: {
          kind: "json",
          value: request.body,
          schema: s.optional(s.lazy(() => apiAiRiskScreenRequestSchema)),
        },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Search Channel3 B2B Product Catalog
   *
   * @returns Catalog search results
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  searchChannel3B2BProductCatalog(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.SearchChannel3B2BProductCatalogRequest = {},
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/channel3/catalog"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [{ name: "q", value: request.q, schema: s.optional(s.string()) }],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Settle an accepted Fabric trade
   *
   * @remarks
   * Requires explicit confirmation in the request and RegAMSP plus RegBMSP peer endorsements. It
   * does not verify PayPal capture.
   *
   * @returns Fabric transaction committed and validated
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeError}
   * when the API answers with an error status — narrow on `err.payload.kind`
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  settleAnAcceptedFabricTrade(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeRequest,
    options?: RequestOptions,
  ): ApiPromise<undefined, CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/fabric/trades/{tradeId}/settle"),
        auth: this.#auth.bearerAuth,
        pathParams: [{ name: "tradeId", value: request.tradeId, schema: s.string() }],
        query: [],
        headers: [
          { name: "X-Fabric-Write-Token", value: request.xFabricWriteToken, schema: s.string() },
          { name: "Idempotency-Key", value: uuid(), schema: s.string() },
        ],
        body: { kind: "json", value: request.body, schema: apiFabricTradesSettleRequestSchema },
      },
      {
        success: { kind: "empty" },
        errorFactory: CorridorFlowCrossBorderTradePrototypeApiClient.SettleAnAcceptedFabricTradeError,
      },
      options,
    );
  }

  /**
   * Sign in to a configured demo role
   *
   * @returns Bearer token and role profile
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  signInToAConfiguredDemoRole(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.SignInToAConfiguredDemoRoleRequest,
    options?: RequestOptions,
  ): ApiPromise<undefined, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/auth/login"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: authLoginRequestSchema },
      },
      {
        success: { kind: "empty" },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Submit a new INR/SGD trade proposal to Fabric
   *
   * @remarks
   * Requires the Fabric write feature flag and a rotated signing identity. Private trade details
   * and salt are sent as transient proposal data; this writes to the permanent test ledger.
   *
   * @returns Fabric transaction committed and validated
   *
   * @throws {@link
   * CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricError} when
   * the API answers with an error status — narrow on `err.payload.kind`
   *
   * @throws {@link CorridorFlowCrossBorderTradePrototypeApiError} when no usable response was
   * produced: a connection failure, a timeout, a body that would not decode, a value that would not
   * encode, or a credential that could not be obtained
   */
  submitANewInrSgdTradeProposalToFabric(
    request: CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricRequest,
    options?: RequestOptions,
  ): ApiPromise<
    undefined,
    CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricError
  > {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/fabric/trades/propose"),
        auth: this.#auth.bearerAuth,
        pathParams: [],
        query: [],
        headers: [
          { name: "X-Fabric-Write-Token", value: request.xFabricWriteToken, schema: s.string() },
          { name: "Idempotency-Key", value: uuid(), schema: s.string() },
        ],
        body: { kind: "json", value: request.body, schema: apiFabricTradesProposeRequestSchema },
      },
      {
        success: { kind: "empty" },
        errorFactory:
          CorridorFlowCrossBorderTradePrototypeApiClient.SubmitANewInrSgdTradeProposalToFabricError,
      },
      options,
    );
  }
}

export namespace CorridorFlowCrossBorderTradePrototypeApiClient {
  export type AcceptAFabricTradeProposalAsTheCounterpartyBankRequest = {
    tradeId: string;
    xFabricWriteToken: string;
  };

  export class AcceptAFabricTradeProposalAsTheCounterpartyBankError extends ApiError {
    declare readonly payload: Declared<"error400", undefined> | Declared<"error503", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<AcceptAFabricTradeProposalAsTheCounterpartyBankError> = [
      { on: 400, kind: "error400", decode: { kind: "empty" } },
      { on: 503, kind: "error503", decode: { kind: "empty" } },
    ];
  }

  export type CalculateIndicativeDemoQuoteWithOptionalGeminiExplanationRequest = {
    body?: ApiAiNegotiateRequest;
  };

  export type CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerRequest = {
    id: string;
    body: ApiPaypalOrdersCaptureRequest;
  };

  export class CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError extends ApiError {
    declare readonly payload: Declared<"error409", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError> =
      [{ on: 409, kind: "error409", decode: { kind: "empty" } }];
  }

  export type CommitOneFabricSettlementLegDebitOrPayeeCreditRequest = {
    tradeId: string;
    leg: Leg;
    operation: Operation;
    xFabricWriteToken: string;
    body: ApiFabricTradesLegsOperationRequest;
  };

  export class CommitOneFabricSettlementLegDebitOrPayeeCreditError extends ApiError {
    declare readonly payload: Declared<"error400", undefined> | Declared<"error503", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<CommitOneFabricSettlementLegDebitOrPayeeCreditError> = [
      { on: 400, kind: "error400", decode: { kind: "empty" } },
      { on: 503, kind: "error503", decode: { kind: "empty" } },
    ];
  }

  export type CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteRequest = {
    body: ApiPaypalOrdersCreateRequest;
  };

  export class CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError extends ApiError {
    declare readonly payload: Declared<"error409", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError> =
      [{ on: 409, kind: "error409", decode: { kind: "empty" } }];
  }

  export type DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureRequest = {
    id: string;
  };

  export class DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError extends ApiError {
    declare readonly payload: Declared<"error409", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError> =
      [{ on: 409, kind: "error409", decode: { kind: "empty" } }];
  }

  export type DispatchZapierOutboundAutomationWebhookRequest = {
    body?: ApiZapierTriggerRequest;
  };

  export type ElasticObservabilityFinancialCrimeSearchRequest = {
    q?: string;
  };

  export type GetALocalSha256ReceiptDigestForADemoSettlementRequest = {
    tradeId: string;
  };

  export type GetTheIllustrativeUsdFundingQuoteForAnAcceptedDemoTradeRequest = {
    tradeId: string;
  };

  export type MarksTheSampleCounterpartyLegHeldInTheDemoWorkflowRequest = {
    id: string;
  };

  export type ProposeANewSampleTradeInTheDemoWorkflowRequest = {
    body: TradesRequest;
  };

  export class ReadALiveFabricChaincodeSnapshotError extends ApiError {
    declare readonly payload: Declared<"error503", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<ReadALiveFabricChaincodeSnapshotError> = [
      { on: 503, kind: "error503", decode: { kind: "empty" } },
    ];
  }

  export type RetryAFailedPayPalBatchPayoutV1ForASettledDemoTradeRequest = {
    body: ApiPaypalPayoutsBatchRequest;
  };

  export type RunDeterministicSampleCorridorBlocklistChecksWithOptionalGeminiExplanationRequest = {
    body?: ApiAiRiskScreenRequest;
  };

  export type SearchChannel3B2BProductCatalogRequest = {
    q?: string;
  };

  export type SettleAnAcceptedFabricTradeRequest = {
    tradeId: string;
    xFabricWriteToken: string;
    body: ApiFabricTradesSettleRequest;
  };

  export class SettleAnAcceptedFabricTradeError extends ApiError {
    declare readonly payload: Declared<"error400", undefined> | Declared<"error503", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<SettleAnAcceptedFabricTradeError> = [
      { on: 400, kind: "error400", decode: { kind: "empty" } },
      { on: 503, kind: "error503", decode: { kind: "empty" } },
    ];
  }

  export type SignInToAConfiguredDemoRoleRequest = {
    body: AuthLoginRequest;
  };

  export type SubmitANewInrSgdTradeProposalToFabricRequest = {
    xFabricWriteToken: string;
    body: ApiFabricTradesProposeRequest;
  };

  export class SubmitANewInrSgdTradeProposalToFabricError extends ApiError {
    declare readonly payload: Declared<"error400", undefined> | Declared<"error503", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<SubmitANewInrSgdTradeProposalToFabricError> = [
      { on: 400, kind: "error400", decode: { kind: "empty" } },
      { on: 503, kind: "error503", decode: { kind: "empty" } },
    ];
  }
}

# Raw Reference

**Raw** endpoints, reached through `with_raw_response`, return `ApiResult[T, E]` and never raise for an API error. For the parsed endpoints, see [API Reference](api-reference.md).

> Source: [CorridorFlowCrossBorderTradePrototypeApiClient](corridor_flow_cross_border_trade_prototype_api/client.py)

<details>
<summary><code>def accept_a_fabric_trade_proposal_as_the_counterparty_bank(trade_id: str, x_fabric_write_token: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.accept_a_fabric_trade_proposal_as_the_counterparty_bank(
    "some example string", "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody
```

**Async**

```python
result = await async_client.with_raw_response.accept_a_fabric_trade_proposal_as_the_counterparty_bank(
    "some example string", "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>trade_id</code> | <code>str</code> | Value sent with the request. |
| <code>x_fabric_write_token</code> | <code>str</code> | Value sent with the request. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/accept_a_fabric_trade_proposal_as_the_counterparty_bank_error.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/accept_a_fabric_trade_proposal_as_the_counterparty_bank_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 503 | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def calculate_indicative_demo_quote_with_optional_gemini_explanation(*, body: ApiAiNegotiateRequest | ApiAiNegotiateRequestDict | None = None, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.calculate_indicative_demo_quote_with_optional_gemini_explanation()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.calculate_indicative_demo_quote_with_optional_gemini_explanation()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiAiNegotiateRequest](corridor_flow_cross_border_trade_prototype_api/models/api_ai_negotiate_request.py) \| [ApiAiNegotiateRequestDict](corridor_flow_cross_border_trade_prototype_api/models/api_ai_negotiate_request.py) \| None</code> | The request body.<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger(id_: str, body: ApiPaypalOrdersCaptureRequest | ApiPaypalOrdersCaptureRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger(
    "some example string", ApiPaypalOrdersCaptureRequest(trade_id="some example string")
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody
```

**Async**

```python
result = await async_client.with_raw_response.capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger(
    "some example string", ApiPaypalOrdersCaptureRequest(trade_id="some example string")
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id_</code> | <code>str</code> | Value sent with the request. |
| <code>body</code> | <code>[ApiPaypalOrdersCaptureRequest](corridor_flow_cross_border_trade_prototype_api/models/api_paypal_orders_capture_request.py) \| [ApiPaypalOrdersCaptureRequestDict](corridor_flow_cross_border_trade_prototype_api/models/api_paypal_orders_capture_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger_error.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 409 | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def check_fabric_gateway_query_connectivity(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Reports a live read-only chaincode query probe when Gateway mode is enabled; TCP reachability alone is not treated as a Fabric connection.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.check_fabric_gateway_query_connectivity()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.check_fabric_gateway_query_connectivity()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def commit_one_fabric_settlement_leg_debit_or_payee_credit(trade_id: str, leg: LegOrStr, operation: OperationOrStr, x_fabric_write_token: str, body: ApiFabricTradesLegsOperationRequest | ApiFabricTradesLegsOperationRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires explicit settlement confirmation, a settled trade, and the signing identity for the payer or payee bank. Each call commits a separate ledger transaction.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.commit_one_fabric_settlement_leg_debit_or_payee_credit(
    "some example string", Leg.A, Operation.DEBIT, "some example string", ApiFabricTradesLegsOperationRequest()
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody
```

**Async**

```python
result = await async_client.with_raw_response.commit_one_fabric_settlement_leg_debit_or_payee_credit(
    "some example string", Leg.A, Operation.DEBIT, "some example string", ApiFabricTradesLegsOperationRequest()
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>trade_id</code> | <code>str</code> | Value sent with the request. |
| <code>leg</code> | <code>[LegOrStr](corridor_flow_cross_border_trade_prototype_api/models/enums/leg.py)</code> | Value sent with the request. |
| <code>operation</code> | <code>[OperationOrStr](corridor_flow_cross_border_trade_prototype_api/models/enums/operation.py)</code> | Value sent with the request. |
| <code>x_fabric_write_token</code> | <code>str</code> | Value sent with the request. |
| <code>body</code> | <code>[ApiFabricTradesLegsOperationRequest](corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_legs_operation_request.py) \| [ApiFabricTradesLegsOperationRequestDict](corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_legs_operation_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/commit_one_fabric_settlement_leg_debit_or_payee_credit_error.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/commit_one_fabric_settlement_leg_debit_or_payee_credit_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 503 | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote(body: ApiPaypalOrdersCreateRequest | ApiPaypalOrdersCreateRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote(
    ApiPaypalOrdersCreateRequest()
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        # TODO: Handle 'error' of type
        # CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody
        ...
```

**Async**

```python
result = await async_client.with_raw_response.create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote(
    ApiPaypalOrdersCreateRequest()
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        # TODO: Handle 'error' of type
        # CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody
        ...
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiPaypalOrdersCreateRequest](corridor_flow_cross_border_trade_prototype_api/models/api_paypal_orders_create_request.py) \| [ApiPaypalOrdersCreateRequestDict](corridor_flow_cross_border_trade_prototype_api/models/api_paypal_orders_create_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote_error.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 409 | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def deprecated_direct_settle_endpoint_returns_409_capture_via_api_paypal_orders_id_capture(id_: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.deprecated_direct_settle_endpoint_returns_409_capture_via_api_paypal_orders_id_capture(
    "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        # TODO: Handle 'error' of type
        # DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody
        ...
```

**Async**

```python
result = await async_client.with_raw_response.deprecated_direct_settle_endpoint_returns_409_capture_via_api_paypal_orders_id_capture(
    "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        # TODO: Handle 'error' of type
        # DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody
        ...
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id_</code> | <code>str</code> | Value sent with the request. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/deprecated_direct_settle_endpoint_returns409_capture_via_api_paypal_orders_id_capture_error.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/deprecated_direct_settle_endpoint_returns409_capture_via_api_paypal_orders_id_capture_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 409 | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def dispatch_zapier_outbound_automation_webhook(*, body: ApiZapierTriggerRequest | ApiZapierTriggerRequestDict | None = None, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.dispatch_zapier_outbound_automation_webhook()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.dispatch_zapier_outbound_automation_webhook()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiZapierTriggerRequest](corridor_flow_cross_border_trade_prototype_api/models/api_zapier_trigger_request.py) \| [ApiZapierTriggerRequestDict](corridor_flow_cross_border_trade_prototype_api/models/api_zapier_trigger_request.py) \| None</code> | The request body.<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def elastic_observability_financial_crime_search(*, q: str | None = None, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.elastic_observability_financial_crime_search()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.elastic_observability_financial_crime_search()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>q</code> | <code>str \| None</code> | Value sent with the request.<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def end_the_current_demo_session(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.end_the_current_demo_session()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.end_the_current_demo_session()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_a_local_sha_256_receipt_digest_for_a_demo_settlement(trade_id: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.get_a_local_sha_256_receipt_digest_for_a_demo_settlement("some example string")
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.get_a_local_sha_256_receipt_digest_for_a_demo_settlement(
    "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>trade_id</code> | <code>str</code> | Value sent with the request. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_the_illustrative_usd_funding_quote_for_an_accepted_demo_trade(trade_id: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.get_the_illustrative_usd_funding_quote_for_an_accepted_demo_trade(
    "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.get_the_illustrative_usd_funding_quote_for_an_accepted_demo_trade(
    "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>trade_id</code> | <code>str</code> | Value sent with the request. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_the_signed_in_operator_identity_and_role(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.get_the_signed_in_operator_identity_and_role()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.get_the_signed_in_operator_identity_and_role()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def health_and_system_status(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.health_and_system_status()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.health_and_system_status()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def list_all_active_and_settled_bilateral_trades(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.list_all_active_and_settled_bilateral_trades()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.list_all_active_and_settled_bilateral_trades()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def marks_the_sample_counterparty_leg_held_in_the_demo_workflow(id_: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.marks_the_sample_counterparty_leg_held_in_the_demo_workflow("some example string")
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.marks_the_sample_counterparty_leg_held_in_the_demo_workflow(
    "some example string"
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id_</code> | <code>str</code> | Value sent with the request. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def propose_a_new_sample_trade_in_the_demo_workflow(body: TradesRequest | TradesRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.propose_a_new_sample_trade_in_the_demo_workflow(TradesRequest())
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.propose_a_new_sample_trade_in_the_demo_workflow(TradesRequest())
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[TradesRequest](corridor_flow_cross_border_trade_prototype_api/models/trades_request.py) \| [TradesRequestDict](corridor_flow_cross_border_trade_prototype_api/models/trades_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def read_a_live_fabric_chaincode_snapshot(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, ReadALiveFabricChaincodeSnapshotErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires a configured Fabric Gateway identity. Evaluates chaincode queries only and never submits a transaction. Private account queries may be denied by chaincode access rules.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.read_a_live_fabric_chaincode_snapshot()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type ReadALiveFabricChaincodeSnapshotErrorBody
```

**Async**

```python
result = await async_client.with_raw_response.read_a_live_fabric_chaincode_snapshot()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type ReadALiveFabricChaincodeSnapshotErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [ReadALiveFabricChaincodeSnapshotErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/read_a_live_fabric_chaincode_snapshot_error.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[ReadALiveFabricChaincodeSnapshotErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/read_a_live_fabric_chaincode_snapshot_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 503 | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def retry_a_failed_pay_pal_batch_payout_v1_for_a_settled_demo_trade(body: ApiPaypalPayoutsBatchRequest | ApiPaypalPayoutsBatchRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.retry_a_failed_pay_pal_batch_payout_v1_for_a_settled_demo_trade(
    ApiPaypalPayoutsBatchRequest()
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.retry_a_failed_pay_pal_batch_payout_v1_for_a_settled_demo_trade(
    ApiPaypalPayoutsBatchRequest()
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiPaypalPayoutsBatchRequest](corridor_flow_cross_border_trade_prototype_api/models/api_paypal_payouts_batch_request.py) \| [ApiPaypalPayoutsBatchRequestDict](corridor_flow_cross_border_trade_prototype_api/models/api_paypal_payouts_batch_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def run_deterministic_sample_corridor_blocklist_checks_with_optional_gemini_explanation(*, body: ApiAiRiskScreenRequest | ApiAiRiskScreenRequestDict | None = None, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.run_deterministic_sample_corridor_blocklist_checks_with_optional_gemini_explanation()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.run_deterministic_sample_corridor_blocklist_checks_with_optional_gemini_explanation()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiAiRiskScreenRequest](corridor_flow_cross_border_trade_prototype_api/models/api_ai_risk_screen_request.py) \| [ApiAiRiskScreenRequestDict](corridor_flow_cross_border_trade_prototype_api/models/api_ai_risk_screen_request.py) \| None</code> | The request body.<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def search_channel3_b2_b_product_catalog(*, q: str | None = None, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.search_channel3_b2_b_product_catalog()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.search_channel3_b2_b_product_catalog()
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>q</code> | <code>str \| None</code> | Value sent with the request.<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def settle_an_accepted_fabric_trade(trade_id: str, x_fabric_write_token: str, body: ApiFabricTradesSettleRequest | ApiFabricTradesSettleRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, SettleAnAcceptedFabricTradeErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires explicit confirmation in the request and RegAMSP plus RegBMSP peer endorsements. It does not verify PayPal capture.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.settle_an_accepted_fabric_trade(
    "some example string", "some example string", ApiFabricTradesSettleRequest()
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type SettleAnAcceptedFabricTradeErrorBody
```

**Async**

```python
result = await async_client.with_raw_response.settle_an_accepted_fabric_trade(
    "some example string", "some example string", ApiFabricTradesSettleRequest()
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type SettleAnAcceptedFabricTradeErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>trade_id</code> | <code>str</code> | Value sent with the request. |
| <code>x_fabric_write_token</code> | <code>str</code> | Value sent with the request. |
| <code>body</code> | <code>[ApiFabricTradesSettleRequest](corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_settle_request.py) \| [ApiFabricTradesSettleRequestDict](corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_settle_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [SettleAnAcceptedFabricTradeErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/settle_an_accepted_fabric_trade_error.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[SettleAnAcceptedFabricTradeErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/settle_an_accepted_fabric_trade_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 503 | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def sign_in_to_a_configured_demo_role(body: AuthLoginRequest | AuthLoginRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.sign_in_to_a_configured_demo_role(
    AuthLoginRequest(operator="some example string", password="some example password")
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.sign_in_to_a_configured_demo_role(
    AuthLoginRequest(operator="some example string", password="some example password")
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[AuthLoginRequest](corridor_flow_cross_border_trade_prototype_api/models/auth_login_request.py) \| [AuthLoginRequestDict](corridor_flow_cross_border_trade_prototype_api/models/auth_login_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def submit_a_new_inr_sgd_trade_proposal_to_fabric(x_fabric_write_token: str, body: ApiFabricTradesProposeRequest | ApiFabricTradesProposeRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[None, SubmitANewInrSgdTradeProposalToFabricErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Requires the Fabric write feature flag and a rotated signing identity. Private trade details and salt are sent as transient proposal data; this writes to the permanent test ledger.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.submit_a_new_inr_sgd_trade_proposal_to_fabric(
    "some example string",
    ApiFabricTradesProposeRequest(
        proposer_msp=ProposerMsp.BANK_A1_MSP,
        ccy_a=CcyA.INR,
        amount_a="some example string",
        ccy_b=CcyB.INR,
        amount_b="some example string",
    ),
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type SubmitANewInrSgdTradeProposalToFabricErrorBody
```

**Async**

```python
result = await async_client.with_raw_response.submit_a_new_inr_sgd_trade_proposal_to_fabric(
    "some example string",
    ApiFabricTradesProposeRequest(
        proposer_msp=ProposerMsp.BANK_A1_MSP,
        ccy_a=CcyA.INR,
        amount_a="some example string",
        ccy_b=CcyB.INR,
        amount_b="some example string",
    ),
)
match result:
    case Success():
        ...  # 2xx, no content
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type SubmitANewInrSgdTradeProposalToFabricErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>x_fabric_write_token</code> | <code>str</code> | Value sent with the request. |
| <code>body</code> | <code>[ApiFabricTradesProposeRequest](corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_propose_request.py) \| [ApiFabricTradesProposeRequestDict](corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_propose_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](corridor_flow_cross_border_trade_prototype_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](corridor_flow_cross_border_trade_prototype_api/core/results.py)&#91;None, [SubmitANewInrSgdTradeProposalToFabricErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/submit_a_new_inr_sgd_trade_proposal_to_fabric_error.py)&#93;</code>

**On `Success`**: the 2xx carries no content; `payload` is <code>None</code>

**On `Failure`**: `error` is <code>[SubmitANewInrSgdTradeProposalToFabricErrorBody](corridor_flow_cross_border_trade_prototype_api/errors/submit_a_new_inr_sgd_trade_proposal_to_fabric_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 503 | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](corridor_flow_cross_border_trade_prototype_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>


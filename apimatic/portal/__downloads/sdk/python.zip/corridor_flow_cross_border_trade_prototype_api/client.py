from __future__ import annotations

from functools import cached_property
from types import TracebackType
from uuid import UUID, uuid4

from typing_extensions import Self

from .auth import AuthSchemes
from .base_client import DEFAULT_TIMEOUT, BaseCorridorFlowCrossBorderTradePrototypeApiClient
from .core import (
    OPERATING_SYSTEM,
    PYTHON_RUNTIME,
    ApiResult,
    BearerAuthScheme,
    HttpClient,
    Httpx2Client,
    LoggingOptionsOrDict,
    RawClient,
    RawError,
    RequestOptionsOrDict,
    RetryOptionsOrDict,
    SecuredRawResponse,
    empty_response,
    json_body,
    no_auth,
    param,
    raw_error_response,
    unwrap,
)
from .errors.accept_a_fabric_trade_proposal_as_the_counterparty_bank_error import (
    AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody,
    accept_a_fabric_trade_proposal_as_the_counterparty_bank_error_mapper,
)
from .errors.capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger_error import (
    CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody,
    capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger_error_mapper,
)
from .errors.commit_one_fabric_settlement_leg_debit_or_payee_credit_error import (
    CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody,
    commit_one_fabric_settlement_leg_debit_or_payee_credit_error_mapper,
)
from .errors.create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote_error import (
    CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody,
    create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote_error_mapper,
)
from .errors.deprecated_direct_settle_endpoint_returns409_capture_via_api_paypal_orders_id_capture_error import (
    DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody,
    deprecated_direct_settle_endpoint_returns409_capture_via_api_paypal_orders_id_capture_error_mapper,
)
from .errors.read_a_live_fabric_chaincode_snapshot_error import (
    ReadALiveFabricChaincodeSnapshotErrorBody,
    read_a_live_fabric_chaincode_snapshot_error_mapper,
)
from .errors.settle_an_accepted_fabric_trade_error import (
    SettleAnAcceptedFabricTradeErrorBody,
    settle_an_accepted_fabric_trade_error_mapper,
)
from .errors.submit_a_new_inr_sgd_trade_proposal_to_fabric_error import (
    SubmitANewInrSgdTradeProposalToFabricErrorBody,
    submit_a_new_inr_sgd_trade_proposal_to_fabric_error_mapper,
)
from .models.api_ai_negotiate_request import ApiAiNegotiateRequest, ApiAiNegotiateRequestDict
from .models.api_ai_risk_screen_request import ApiAiRiskScreenRequest, ApiAiRiskScreenRequestDict
from .models.api_fabric_trades_legs_operation_request import (
    ApiFabricTradesLegsOperationRequest,
    ApiFabricTradesLegsOperationRequestDict,
)
from .models.api_fabric_trades_propose_request import ApiFabricTradesProposeRequest, ApiFabricTradesProposeRequestDict
from .models.api_fabric_trades_settle_request import ApiFabricTradesSettleRequest, ApiFabricTradesSettleRequestDict
from .models.api_paypal_orders_capture_request import ApiPaypalOrdersCaptureRequest, ApiPaypalOrdersCaptureRequestDict
from .models.api_paypal_orders_create_request import ApiPaypalOrdersCreateRequest, ApiPaypalOrdersCreateRequestDict
from .models.api_paypal_payouts_batch_request import ApiPaypalPayoutsBatchRequest, ApiPaypalPayoutsBatchRequestDict
from .models.api_zapier_trigger_request import ApiZapierTriggerRequest, ApiZapierTriggerRequestDict
from .models.auth_login_request import AuthLoginRequest, AuthLoginRequestDict
from .models.enums.leg import LegOrStr
from .models.enums.operation import OperationOrStr
from .models.trades_request import TradesRequest, TradesRequestDict
from .server.environment import Environment
from .server.server import Server


class CorridorFlowCrossBorderTradePrototypeApiClient(BaseCorridorFlowCrossBorderTradePrototypeApiClient[RawClient]):
    def __init__(
        self,
        *,
        environment: Environment = "production",
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        retry_options: int | RetryOptionsOrDict | None = None,
        logging_options: LoggingOptionsOrDict | None = None,
        custom_http_client: HttpClient | None = None,
        bearer_auth: str | None = None,
    ) -> None:
        super().__init__(
            environment=environment,
            base_url=base_url,
            timeout=timeout,
            retry_options=retry_options,
            logging_options=logging_options,
        )
        self._raw_client = RawClient(
            http_client=custom_http_client if custom_http_client is not None else Httpx2Client(timeout=timeout),
            retry_options=self._retry_options,
            logging_options=self._logging_options,
            global_headers=[
                param[str]("User-Agent", "CorridorFlowCrossBorderTradePrototypeApiClient/1.0.0 Python"),
                param[str]("X-APIMatic-Lang", "Python"),
                param[str]("X-APIMatic-Package-Version", "1.0.0"),
                param[str]("X-APIMatic-Gen-Version", "4.0.0"),
                param[str]("X-APIMatic-OS", OPERATING_SYSTEM),
                param[str]("X-APIMatic-Runtime", PYTHON_RUNTIME),
            ],
        )
        self._auth = AuthSchemes(bearer_auth=BearerAuthScheme(bearer_auth) if bearer_auth is not None else no_auth)

    @cached_property
    def with_raw_response(self) -> ApiWithRawResponse:
        return ApiWithRawResponse(self._raw_client, self._server, self._auth)

    def accept_a_fabric_trade_proposal_as_the_counterparty_bank(
        self, trade_id: str, x_fabric_write_token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``POST`` request.

        Args:
            trade_id: Value sent with the request.
            x_fabric_write_token: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Fabric transaction committed and validated

        Raises:
            ApiError: Trade state or transient details are invalid Fabric writes are disabled or identities are not
                configured ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.accept_a_fabric_trade_proposal_as_the_counterparty_bank(
                trade_id, x_fabric_write_token, request_options=request_options
            ),
        )

    def calculate_indicative_demo_quote_with_optional_gemini_explanation(
        self,
        *,
        body: ApiAiNegotiateRequest | ApiAiNegotiateRequestDict | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> None:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Indicative demo trade proposal (static FX benchmark and volume heuristic)

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.calculate_indicative_demo_quote_with_optional_gemini_explanation(
                body=body, request_options=request_options
            ),
        )

    def capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger(
        self,
        id_: str,
        body: ApiPaypalOrdersCaptureRequest | ApiPaypalOrdersCaptureRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> None:
        """Send a ``POST`` request.

        Args:
            id_: Value sent with the request.
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Capture and local demo settlement details

        Raises:
            ApiError: Capture status, amount, or order link does not match the quote ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger(
                id_, body, request_options=request_options
            ),
        )

    def check_fabric_gateway_query_connectivity(self, *, request_options: RequestOptionsOrDict | None = None) -> None:
        """Reports a live read-only chaincode query probe when Gateway mode is enabled; TCP reachability alone is not
        treated as a Fabric connection.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Gateway status and demo or live ledger source

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self.with_raw_response.check_fabric_gateway_query_connectivity(request_options=request_options))

    def commit_one_fabric_settlement_leg_debit_or_payee_credit(
        self,
        trade_id: str,
        leg: LegOrStr,
        operation: OperationOrStr,
        x_fabric_write_token: str,
        body: ApiFabricTradesLegsOperationRequest | ApiFabricTradesLegsOperationRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> None:
        """Requires explicit settlement confirmation, a settled trade, and the signing identity for the payer or payee
        bank. Each call commits a separate ledger transaction.

        Args:
            trade_id: Value sent with the request.
            leg: Value sent with the request.
            operation: Value sent with the request.
            x_fabric_write_token: Value sent with the request.
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Fabric transaction committed and validated

        Raises:
            ApiError: Trade state, settlement confirmation, or chaincode validation failed Fabric writes are disabled or
                identities are not configured ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.commit_one_fabric_settlement_leg_debit_or_payee_credit(
                trade_id, leg, operation, x_fabric_write_token, body, request_options=request_options
            ),
        )

    def create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote(
        self,
        body: ApiPaypalOrdersCreateRequest | ApiPaypalOrdersCreateRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> None:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            PayPal Order response with server USD funding quote

        Raises:
            ApiError: Trade is not accepted or has a conflicting funding quote ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote(
                body, request_options=request_options
            ),
        )

    def deprecated_direct_settle_endpoint_returns_409_capture_via_api_paypal_orders_id_capture(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``POST`` request.

        Args:
            id_: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Raises:
            ApiError: Settlement requires capturing a linked PayPal order ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.deprecated_direct_settle_endpoint_returns_409_capture_via_api_paypal_orders_id_capture(
                id_, request_options=request_options
            ),
        )

    def dispatch_zapier_outbound_automation_webhook(
        self,
        *,
        body: ApiZapierTriggerRequest | ApiZapierTriggerRequestDict | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> None:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Zapier delivery status

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.dispatch_zapier_outbound_automation_webhook(
                body=body, request_options=request_options
            ),
        )

    def elastic_observability_financial_crime_search(
        self, *, q: str | None = None, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``GET`` request.

        Args:
            q: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Elastic search hits and query latency

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.elastic_observability_financial_crime_search(q=q, request_options=request_options)
        )

    def end_the_current_demo_session(self, *, request_options: RequestOptionsOrDict | None = None) -> None:
        """Send a ``POST`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Session revoked

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self.with_raw_response.end_the_current_demo_session(request_options=request_options))

    def get_a_local_sha_256_receipt_digest_for_a_demo_settlement(
        self, trade_id: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``GET`` request.

        Args:
            trade_id: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Local demo digest; not proof of Fabric, regulator approval, or external payment

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.get_a_local_sha_256_receipt_digest_for_a_demo_settlement(
                trade_id, request_options=request_options
            ),
        )

    def get_the_illustrative_usd_funding_quote_for_an_accepted_demo_trade(
        self, trade_id: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``GET`` request.

        Args:
            trade_id: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Static demo FX quote; not a live market rate

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.get_the_illustrative_usd_funding_quote_for_an_accepted_demo_trade(
                trade_id, request_options=request_options
            ),
        )

    def get_the_signed_in_operator_identity_and_role(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Active identity profile

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.get_the_signed_in_operator_identity_and_role(request_options=request_options)
        )

    def health_and_system_status(self, *, request_options: RequestOptionsOrDict | None = None) -> None:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            System operational status

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self.with_raw_response.health_and_system_status(request_options=request_options))

    def list_all_active_and_settled_bilateral_trades(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Array of trade composites

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.list_all_active_and_settled_bilateral_trades(request_options=request_options)
        )

    def marks_the_sample_counterparty_leg_held_in_the_demo_workflow(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``POST`` request.

        Args:
            id_: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Accepted trade

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.marks_the_sample_counterparty_leg_held_in_the_demo_workflow(
                id_, request_options=request_options
            ),
        )

    def propose_a_new_sample_trade_in_the_demo_workflow(
        self, body: TradesRequest | TradesRequestDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Proposed trade record

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.propose_a_new_sample_trade_in_the_demo_workflow(
                body, request_options=request_options
            ),
        )

    def read_a_live_fabric_chaincode_snapshot(self, *, request_options: RequestOptionsOrDict | None = None) -> None:
        """Requires a configured Fabric Gateway identity. Evaluates chaincode queries only and never submits a
        transaction. Private account queries may be denied by chaincode access rules.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Results and per-query errors from read-only chaincode evaluations

        Raises:
            ApiError: Gateway disabled, unavailable, or misconfigured ``error`` is ``RawError``."""
        return unwrap(self.with_raw_response.read_a_live_fabric_chaincode_snapshot(request_options=request_options))

    def retry_a_failed_pay_pal_batch_payout_v1_for_a_settled_demo_trade(
        self,
        body: ApiPaypalPayoutsBatchRequest | ApiPaypalPayoutsBatchRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> None:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Payout batch response

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.retry_a_failed_pay_pal_batch_payout_v1_for_a_settled_demo_trade(
                body, request_options=request_options
            ),
        )

    def run_deterministic_sample_corridor_blocklist_checks_with_optional_gemini_explanation(
        self,
        *,
        body: ApiAiRiskScreenRequest | ApiAiRiskScreenRequestDict | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> None:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Risk score and pass/refuse verdict

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.run_deterministic_sample_corridor_blocklist_checks_with_optional_gemini_explanation(
                body=body, request_options=request_options
            ),
        )

    def search_channel3_b2_b_product_catalog(
        self, *, q: str | None = None, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``GET`` request.

        Args:
            q: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Catalog search results

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self.with_raw_response.search_channel3_b2_b_product_catalog(q=q, request_options=request_options))

    def settle_an_accepted_fabric_trade(
        self,
        trade_id: str,
        x_fabric_write_token: str,
        body: ApiFabricTradesSettleRequest | ApiFabricTradesSettleRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> None:
        """Requires explicit confirmation in the request and RegAMSP plus RegBMSP peer endorsements. It does not verify
        PayPal capture.

        Args:
            trade_id: Value sent with the request.
            x_fabric_write_token: Value sent with the request.
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Fabric transaction committed and validated

        Raises:
            ApiError: Trade is not accepted or explicit confirmation is missing Fabric writes are disabled or identities
                are not configured ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.settle_an_accepted_fabric_trade(
                trade_id, x_fabric_write_token, body, request_options=request_options
            ),
        )

    def sign_in_to_a_configured_demo_role(
        self, body: AuthLoginRequest | AuthLoginRequestDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Bearer token and role profile

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self.with_raw_response.sign_in_to_a_configured_demo_role(body, request_options=request_options))

    def submit_a_new_inr_sgd_trade_proposal_to_fabric(
        self,
        x_fabric_write_token: str,
        body: ApiFabricTradesProposeRequest | ApiFabricTradesProposeRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> None:
        """Requires the Fabric write feature flag and a rotated signing identity. Private trade details and salt are
        sent as transient proposal data; this writes to the permanent test ledger.

        Args:
            x_fabric_write_token: Value sent with the request.
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Fabric transaction committed and validated

        Raises:
            ApiError: Invalid proposal or chaincode rejected it Fabric writes are disabled or identities are not
                configured ``error`` is ``RawError``."""
        return unwrap(
            self.with_raw_response.submit_a_new_inr_sgd_trade_proposal_to_fabric(
                x_fabric_write_token, body, request_options=request_options
            ),
        )

    def close(self) -> None:
        self._raw_client.http_client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, exc_tb: TracebackType | None
    ) -> None:
        self.close()


class ApiWithRawResponse(SecuredRawResponse[RawClient, Server, AuthSchemes]):
    def accept_a_fabric_trade_proposal_as_the_counterparty_bank(
        self, trade_id: str, x_fabric_write_token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody]:
        """Send a ``POST`` request.

        Args:
            trade_id: Value sent with the request.
            x_fabric_write_token: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/fabric/trades/{tradeId}/accept"),
            path_params=[param[str]("tradeId", trade_id)],
            headers=[param[str]("X-Fabric-Write-Token", x_fabric_write_token), param[UUID]("Idempotency-Key", uuid4())],
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=accept_a_fabric_trade_proposal_as_the_counterparty_bank_error_mapper,
            request_options=request_options,
        )

    def calculate_indicative_demo_quote_with_optional_gemini_explanation(
        self,
        *,
        body: ApiAiNegotiateRequest | ApiAiNegotiateRequestDict | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[None, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/ai/negotiate"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiAiNegotiateRequest | ApiAiNegotiateRequestDict | None](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger(
        self,
        id_: str,
        body: ApiPaypalOrdersCaptureRequest | ApiPaypalOrdersCaptureRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[None, CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody]:
        """Send a ``POST`` request.

        Args:
            id_: Value sent with the request.
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/paypal/orders/{id}/capture"),
            path_params=[param[str]("id", id_)],
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiPaypalOrdersCaptureRequest | ApiPaypalOrdersCaptureRequestDict](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger_error_mapper,
            request_options=request_options,
        )

    def check_fabric_gateway_query_connectivity(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Reports a live read-only chaincode query probe when Gateway mode is enabled; TCP reachability alone is not
        treated as a Fabric connection.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/fabric/status"),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def commit_one_fabric_settlement_leg_debit_or_payee_credit(
        self,
        trade_id: str,
        leg: LegOrStr,
        operation: OperationOrStr,
        x_fabric_write_token: str,
        body: ApiFabricTradesLegsOperationRequest | ApiFabricTradesLegsOperationRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[None, CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody]:
        """Requires explicit settlement confirmation, a settled trade, and the signing identity for the payer or payee
        bank. Each call commits a separate ledger transaction.

        Args:
            trade_id: Value sent with the request.
            leg: Value sent with the request.
            operation: Value sent with the request.
            x_fabric_write_token: Value sent with the request.
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/fabric/trades/{tradeId}/legs/{leg}/{operation}"),
            path_params=[
                param[str]("tradeId", trade_id),
                param[LegOrStr]("leg", leg),
                param[OperationOrStr]("operation", operation),
            ],
            headers=[param[str]("X-Fabric-Write-Token", x_fabric_write_token), param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiFabricTradesLegsOperationRequest | ApiFabricTradesLegsOperationRequestDict](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=commit_one_fabric_settlement_leg_debit_or_payee_credit_error_mapper,
            request_options=request_options,
        )

    def create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote(
        self,
        body: ApiPaypalOrdersCreateRequest | ApiPaypalOrdersCreateRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[None, CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/paypal/orders/create"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiPaypalOrdersCreateRequest | ApiPaypalOrdersCreateRequestDict](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote_error_mapper,
            request_options=request_options,
        )

    def deprecated_direct_settle_endpoint_returns_409_capture_via_api_paypal_orders_id_capture(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody]:
        """Send a ``POST`` request.

        Args:
            id_: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/trades/{id}/settle"),
            path_params=[param[str]("id", id_)],
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=deprecated_direct_settle_endpoint_returns409_capture_via_api_paypal_orders_id_capture_error_mapper,
            request_options=request_options,
        )

    def dispatch_zapier_outbound_automation_webhook(
        self,
        *,
        body: ApiZapierTriggerRequest | ApiZapierTriggerRequestDict | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[None, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/zapier/trigger"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiZapierTriggerRequest | ApiZapierTriggerRequestDict | None](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def elastic_observability_financial_crime_search(
        self, *, q: str | None = None, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``GET`` request.

        Args:
            q: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/elastic/search"),
            query_params=[param[str | None]("q", q)],
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def end_the_current_demo_session(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``POST`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/auth/logout"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def get_a_local_sha_256_receipt_digest_for_a_demo_settlement(
        self, trade_id: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``GET`` request.

        Args:
            trade_id: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/receipts/{tradeId}"),
            path_params=[param[str]("tradeId", trade_id)],
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def get_the_illustrative_usd_funding_quote_for_an_accepted_demo_trade(
        self, trade_id: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``GET`` request.

        Args:
            trade_id: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/paypal/orders/quote/{tradeId}"),
            path_params=[param[str]("tradeId", trade_id)],
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def get_the_signed_in_operator_identity_and_role(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/me"),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def health_and_system_status(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/health"),
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def list_all_active_and_settled_bilateral_trades(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/trades"),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def marks_the_sample_counterparty_leg_held_in_the_demo_workflow(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``POST`` request.

        Args:
            id_: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/trades/{id}/accept"),
            path_params=[param[str]("id", id_)],
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def propose_a_new_sample_trade_in_the_demo_workflow(
        self, body: TradesRequest | TradesRequestDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/trades"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[TradesRequest | TradesRequestDict](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def read_a_live_fabric_chaincode_snapshot(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, ReadALiveFabricChaincodeSnapshotErrorBody]:
        """Requires a configured Fabric Gateway identity. Evaluates chaincode queries only and never submits a
        transaction. Private account queries may be denied by chaincode access rules.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/fabric/ledger"),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=read_a_live_fabric_chaincode_snapshot_error_mapper,
            request_options=request_options,
        )

    def retry_a_failed_pay_pal_batch_payout_v1_for_a_settled_demo_trade(
        self,
        body: ApiPaypalPayoutsBatchRequest | ApiPaypalPayoutsBatchRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[None, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/paypal/payouts/batch"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiPaypalPayoutsBatchRequest | ApiPaypalPayoutsBatchRequestDict](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def run_deterministic_sample_corridor_blocklist_checks_with_optional_gemini_explanation(
        self,
        *,
        body: ApiAiRiskScreenRequest | ApiAiRiskScreenRequestDict | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[None, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/ai/risk-screen"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiAiRiskScreenRequest | ApiAiRiskScreenRequestDict | None](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def search_channel3_b2_b_product_catalog(
        self, *, q: str | None = None, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``GET`` request.

        Args:
            q: Value sent with the request.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/channel3/catalog"),
            query_params=[param[str | None]("q", q)],
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def settle_an_accepted_fabric_trade(
        self,
        trade_id: str,
        x_fabric_write_token: str,
        body: ApiFabricTradesSettleRequest | ApiFabricTradesSettleRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[None, SettleAnAcceptedFabricTradeErrorBody]:
        """Requires explicit confirmation in the request and RegAMSP plus RegBMSP peer endorsements. It does not verify
        PayPal capture.

        Args:
            trade_id: Value sent with the request.
            x_fabric_write_token: Value sent with the request.
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/fabric/trades/{tradeId}/settle"),
            path_params=[param[str]("tradeId", trade_id)],
            headers=[param[str]("X-Fabric-Write-Token", x_fabric_write_token), param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiFabricTradesSettleRequest | ApiFabricTradesSettleRequestDict](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=settle_an_accepted_fabric_trade_error_mapper,
            request_options=request_options,
        )

    def sign_in_to_a_configured_demo_role(
        self, body: AuthLoginRequest | AuthLoginRequestDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/auth/login"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[AuthLoginRequest | AuthLoginRequestDict](body),
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def submit_a_new_inr_sgd_trade_proposal_to_fabric(
        self,
        x_fabric_write_token: str,
        body: ApiFabricTradesProposeRequest | ApiFabricTradesProposeRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[None, SubmitANewInrSgdTradeProposalToFabricErrorBody]:
        """Requires the Fabric write feature flag and a rotated signing identity. Private trade details and salt are
        sent as transient proposal data; this writes to the permanent test ledger.

        Args:
            x_fabric_write_token: Value sent with the request.
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/fabric/trades/propose"),
            headers=[param[str]("X-Fabric-Write-Token", x_fabric_write_token), param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiFabricTradesProposeRequest | ApiFabricTradesProposeRequestDict](body),
            auth_scheme=self._auth.bearer_auth,
            decoder=empty_response,
            error_mapper=submit_a_new_inr_sgd_trade_proposal_to_fabric_error_mapper,
            request_options=request_options,
        )


Client = CorridorFlowCrossBorderTradePrototypeApiClient

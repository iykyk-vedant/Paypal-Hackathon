from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError

CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody: TypeAlias = RawError


@dataclass(frozen=True, slots=True)
class _CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError:
    def map(
        self, status_code: int, content: bytes
    ) -> CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody:
        match status_code:
            case 409:
                return RawError(status_code, content)
            case _:
                return RawError(status_code, content)


create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote_error_mapper: Final[
    ErrorMapper[CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody]
] = _CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteError()

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError

DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody: TypeAlias = RawError


@dataclass(frozen=True, slots=True)
class _DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError:
    def map(
        self, status_code: int, content: bytes
    ) -> DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody:
        match status_code:
            case 409:
                return RawError(status_code, content)
            case _:
                return RawError(status_code, content)


deprecated_direct_settle_endpoint_returns409_capture_via_api_paypal_orders_id_capture_error_mapper: Final[
    ErrorMapper[DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody]
] = _DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureError()

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError

SettleAnAcceptedFabricTradeErrorBody: TypeAlias = RawError


@dataclass(frozen=True, slots=True)
class _SettleAnAcceptedFabricTradeError:
    def map(self, status_code: int, content: bytes) -> SettleAnAcceptedFabricTradeErrorBody:
        match status_code:
            case 400 | 503:
                return RawError(status_code, content)
            case _:
                return RawError(status_code, content)


settle_an_accepted_fabric_trade_error_mapper: Final[
    ErrorMapper[SettleAnAcceptedFabricTradeErrorBody]
] = _SettleAnAcceptedFabricTradeError()

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError

ReadALiveFabricChaincodeSnapshotErrorBody: TypeAlias = RawError


@dataclass(frozen=True, slots=True)
class _ReadALiveFabricChaincodeSnapshotError:
    def map(self, status_code: int, content: bytes) -> ReadALiveFabricChaincodeSnapshotErrorBody:
        match status_code:
            case 503:
                return RawError(status_code, content)
            case _:
                return RawError(status_code, content)


read_a_live_fabric_chaincode_snapshot_error_mapper: Final[
    ErrorMapper[ReadALiveFabricChaincodeSnapshotErrorBody]
] = _ReadALiveFabricChaincodeSnapshotError()

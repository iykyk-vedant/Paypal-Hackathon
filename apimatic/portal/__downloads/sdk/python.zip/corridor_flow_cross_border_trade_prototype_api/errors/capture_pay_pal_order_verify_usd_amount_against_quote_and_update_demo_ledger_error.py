from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError

CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody: TypeAlias = RawError


@dataclass(frozen=True, slots=True)
class _CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError:
    def map(
        self, status_code: int, content: bytes
    ) -> CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody:
        match status_code:
            case 409:
                return RawError(status_code, content)
            case _:
                return RawError(status_code, content)


capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger_error_mapper: Final[
    ErrorMapper[CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody]
] = _CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerError()

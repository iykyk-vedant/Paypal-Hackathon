from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError

SubmitANewInrSgdTradeProposalToFabricErrorBody: TypeAlias = RawError


@dataclass(frozen=True, slots=True)
class _SubmitANewInrSgdTradeProposalToFabricError:
    def map(self, status_code: int, content: bytes) -> SubmitANewInrSgdTradeProposalToFabricErrorBody:
        match status_code:
            case 400 | 503:
                return RawError(status_code, content)
            case _:
                return RawError(status_code, content)


submit_a_new_inr_sgd_trade_proposal_to_fabric_error_mapper: Final[
    ErrorMapper[SubmitANewInrSgdTradeProposalToFabricErrorBody]
] = _SubmitANewInrSgdTradeProposalToFabricError()

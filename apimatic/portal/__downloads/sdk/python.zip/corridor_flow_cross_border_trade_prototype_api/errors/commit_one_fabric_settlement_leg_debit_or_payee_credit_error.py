from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError

CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody: TypeAlias = RawError


@dataclass(frozen=True, slots=True)
class _CommitOneFabricSettlementLegDebitOrPayeeCreditError:
    def map(self, status_code: int, content: bytes) -> CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody:
        match status_code:
            case 400 | 503:
                return RawError(status_code, content)
            case _:
                return RawError(status_code, content)


commit_one_fabric_settlement_leg_debit_or_payee_credit_error_mapper: Final[
    ErrorMapper[CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody]
] = _CommitOneFabricSettlementLegDebitOrPayeeCreditError()

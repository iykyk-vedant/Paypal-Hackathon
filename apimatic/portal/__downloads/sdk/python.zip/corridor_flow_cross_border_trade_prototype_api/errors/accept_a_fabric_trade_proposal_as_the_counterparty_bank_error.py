from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError

AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody: TypeAlias = RawError


@dataclass(frozen=True, slots=True)
class _AcceptAFabricTradeProposalAsTheCounterpartyBankError:
    def map(self, status_code: int, content: bytes) -> AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody:
        match status_code:
            case 400 | 503:
                return RawError(status_code, content)
            case _:
                return RawError(status_code, content)


accept_a_fabric_trade_proposal_as_the_counterparty_bank_error_mapper: Final[
    ErrorMapper[AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody]
] = _AcceptAFabricTradeProposalAsTheCounterpartyBankError()

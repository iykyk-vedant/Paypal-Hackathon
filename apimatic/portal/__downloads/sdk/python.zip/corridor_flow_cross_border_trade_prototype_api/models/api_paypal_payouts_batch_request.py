from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ApiPaypalPayoutsBatchRequest(SdkBaseModel):
    trade_id: Optional[str] = Field(default=UNSET, alias="tradeId")


class ApiPaypalPayoutsBatchRequestDict(TypedDict):
    trade_id: NotRequired[str]

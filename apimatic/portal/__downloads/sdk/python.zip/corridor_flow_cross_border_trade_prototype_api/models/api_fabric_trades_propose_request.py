from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.ccy_a import CcyAOrStr
from .enums.ccy_b import CcyBOrStr
from .enums.proposer_msp import ProposerMspOrStr


class ApiFabricTradesProposeRequest(SdkBaseModel):
    proposer_msp: ProposerMspOrStr = Field(alias="proposerMsp")
    ccy_a: CcyAOrStr = Field(alias="ccyA")
    amount_a: str = Field(alias="amountA")
    """Positive currency minor units"""

    ccy_b: CcyBOrStr = Field(alias="ccyB")
    amount_b: str = Field(alias="amountB")
    """Positive currency minor units"""

    reference: Optional[str] = UNSET


class ApiFabricTradesProposeRequestDict(TypedDict):
    proposer_msp: ProposerMspOrStr
    ccy_a: CcyAOrStr
    amount_a: str
    ccy_b: CcyBOrStr
    amount_b: str
    reference: NotRequired[str]

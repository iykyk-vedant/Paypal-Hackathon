from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class TradesRequest(SdkBaseModel):
    proposer: Optional[str] = UNSET
    cparty: Optional[str] = UNSET
    ccy_a: Optional[str] = Field(default=UNSET, alias="ccyA")
    amount_a: Optional[float] = Field(default=UNSET, alias="amountA")
    ccy_b: Optional[str] = Field(default=UNSET, alias="ccyB")
    amount_b: Optional[float] = Field(default=UNSET, alias="amountB")
    fx_rate: Optional[str] = Field(default=UNSET, alias="fxRate")
    reference: Optional[str] = UNSET


class TradesRequestDict(TypedDict):
    proposer: NotRequired[str]
    cparty: NotRequired[str]
    ccy_a: NotRequired[str]
    amount_a: NotRequired[float]
    ccy_b: NotRequired[str]
    amount_b: NotRequired[float]
    fx_rate: NotRequired[str]
    reference: NotRequired[str]

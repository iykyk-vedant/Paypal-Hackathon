from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ApiPaypalOrdersCreateRequest(SdkBaseModel):
    trade_id: Optional[str] = Field(default=UNSET, alias="tradeId")
    description: Optional[str] = UNSET


class ApiPaypalOrdersCreateRequestDict(TypedDict):
    trade_id: NotRequired[str]
    description: NotRequired[str]

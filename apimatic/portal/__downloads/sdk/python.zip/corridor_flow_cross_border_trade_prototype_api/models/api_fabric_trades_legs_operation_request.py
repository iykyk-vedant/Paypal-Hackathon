from __future__ import annotations

from typing import Literal

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiFabricTradesLegsOperationRequest(SdkBaseModel):
    confirm_settlement: Literal["True"] = Field(default="True", alias="confirmSettlement")


class ApiFabricTradesLegsOperationRequestDict(TypedDict):
    confirm_settlement: Literal["True"]

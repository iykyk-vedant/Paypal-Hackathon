from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiPaypalOrdersCaptureRequest(SdkBaseModel):
    trade_id: str = Field(alias="tradeId")


class ApiPaypalOrdersCaptureRequestDict(TypedDict):
    trade_id: str

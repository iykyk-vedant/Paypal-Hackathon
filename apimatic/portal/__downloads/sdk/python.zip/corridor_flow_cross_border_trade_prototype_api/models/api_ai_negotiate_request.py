from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ApiAiNegotiateRequest(SdkBaseModel):
    buyer_org: Optional[str] = Field(default=UNSET, alias="buyerOrg")
    seller_org: Optional[str] = Field(default=UNSET, alias="sellerOrg")
    currency_from: Optional[str] = Field(default=UNSET, alias="currencyFrom")
    currency_to: Optional[str] = Field(default=UNSET, alias="currencyTo")
    amount_from: Optional[float] = Field(default=UNSET, alias="amountFrom")


class ApiAiNegotiateRequestDict(TypedDict):
    buyer_org: NotRequired[str]
    seller_org: NotRequired[str]
    currency_from: NotRequired[str]
    currency_to: NotRequired[str]
    amount_from: NotRequired[float]

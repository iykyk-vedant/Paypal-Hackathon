from __future__ import annotations

from typing import Any

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ApiZapierTriggerRequest(SdkBaseModel):
    event_type: Optional[str] = Field(default=UNSET, alias="eventType")
    payload: Optional[Any] = UNSET


class ApiZapierTriggerRequestDict(TypedDict):
    event_type: NotRequired[str]
    payload: NotRequired[Any]

from __future__ import annotations

from typing_extensions import TypedDict

from ..core import SdkBaseModel


class AuthLoginRequest(SdkBaseModel):
    operator: str
    password: str


class AuthLoginRequestDict(TypedDict):
    operator: str
    password: str

from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ApiAiRiskScreenRequest(SdkBaseModel):
    trade_id: Optional[str] = Field(default=UNSET, alias="tradeId")
    amount_a: Optional[str] = Field(default=UNSET, alias="amountA")
    currency_a: Optional[str] = Field(default=UNSET, alias="currencyA")
    amount_b: Optional[str] = Field(default=UNSET, alias="amountB")
    currency_b: Optional[str] = Field(default=UNSET, alias="currencyB")


class ApiAiRiskScreenRequestDict(TypedDict):
    trade_id: NotRequired[str]
    amount_a: NotRequired[str]
    currency_a: NotRequired[str]
    amount_b: NotRequired[str]
    currency_b: NotRequired[str]

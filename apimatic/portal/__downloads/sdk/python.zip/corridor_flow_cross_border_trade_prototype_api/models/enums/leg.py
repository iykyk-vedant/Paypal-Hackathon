from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class Leg(str, Enum):
    A = "A"
    B = "B"

    __str__ = str.__str__


LegOrStr: TypeAlias = Annotated[Leg | str, open_enum_validator(Leg)]

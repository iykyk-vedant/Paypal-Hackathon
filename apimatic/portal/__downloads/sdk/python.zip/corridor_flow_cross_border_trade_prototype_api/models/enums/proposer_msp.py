from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class ProposerMsp(str, Enum):
    BANK_A1_MSP = "BankA1MSP"
    BANK_B1_MSP = "BankB1MSP"

    __str__ = str.__str__


ProposerMspOrStr: TypeAlias = Annotated[ProposerMsp | str, open_enum_validator(ProposerMsp)]

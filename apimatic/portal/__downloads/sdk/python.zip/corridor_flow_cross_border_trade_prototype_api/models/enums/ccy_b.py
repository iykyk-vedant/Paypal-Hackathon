from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class CcyB(str, Enum):
    INR = "INR"
    SGD = "SGD"

    __str__ = str.__str__


CcyBOrStr: TypeAlias = Annotated[CcyB | str, open_enum_validator(CcyB)]

from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class CcyA(str, Enum):
    INR = "INR"
    SGD = "SGD"

    __str__ = str.__str__


CcyAOrStr: TypeAlias = Annotated[CcyA | str, open_enum_validator(CcyA)]

<!-- Generated file — do not edit; regenerated with the SDK. -->

# Client — operations

Accessor: `client` · Source: `corridor_flow_cross_border_trade_prototype_api/client.py` · 24 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded, and an operation with no table mentions nothing but builtins and those.

### client.accept_a_fabric_trade_proposal_as_the_counterparty_bank

- **Route**: `POST /api/fabric/trades/{tradeId}/accept`
- **Auth**: `bearer_auth`
- **Signature**: `def accept_a_fabric_trade_proposal_as_the_counterparty_bank(trade_id: str, x_fabric_write_token: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `trade_id`, `x_fabric_write_token`
- **Params**: `trade_id` — path `tradeId` · `x_fabric_write_token` — header `X-Fabric-Write-Token`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody]`
- **Error**: `AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody` — **Case A (typed)**
- **Error arms**: `RawError` [400, 503, anything unmapped]

| Type | Source |
| --- | --- |
| `AcceptAFabricTradeProposalAsTheCounterpartyBankErrorBody` | `corridor_flow_cross_border_trade_prototype_api/errors/accept_a_fabric_trade_proposal_as_the_counterparty_bank_error.py` |

### client.calculate_indicative_demo_quote_with_optional_gemini_explanation

- **Route**: `POST /api/ai/negotiate`
- **Auth**: `bearer_auth`
- **Signature**: `def calculate_indicative_demo_quote_with_optional_gemini_explanation(*, body: ApiAiNegotiateRequest | ApiAiNegotiateRequestDict | None = None, request_options: RequestOptionsOrDict | None = None)`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiAiNegotiateRequest` | `corridor_flow_cross_border_trade_prototype_api/models/api_ai_negotiate_request.py` |
| `ApiAiNegotiateRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/api_ai_negotiate_request.py` |

### client.capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger

- **Route**: `POST /api/paypal/orders/{id}/capture`
- **Auth**: `bearer_auth`
- **Signature**: `def capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger(id_: str, body: ApiPaypalOrdersCaptureRequest | ApiPaypalOrdersCaptureRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `id_`, `body`
- **Params**: `id_` — path `id` · `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody]`
- **Error**: `CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody` — **Case A (typed)**
- **Error arms**: `RawError` [409, anything unmapped]

| Type | Source |
| --- | --- |
| `ApiPaypalOrdersCaptureRequest` | `corridor_flow_cross_border_trade_prototype_api/models/api_paypal_orders_capture_request.py` |
| `ApiPaypalOrdersCaptureRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/api_paypal_orders_capture_request.py` |
| `CapturePayPalOrderVerifyUsdAmountAgainstQuoteAndUpdateDemoLedgerErrorBody` | `corridor_flow_cross_border_trade_prototype_api/errors/capture_pay_pal_order_verify_usd_amount_against_quote_and_update_demo_ledger_error.py` |

### client.check_fabric_gateway_query_connectivity

- **Route**: `GET /api/fabric/status`
- **Auth**: `bearer_auth`
- **Signature**: `def check_fabric_gateway_query_connectivity(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.commit_one_fabric_settlement_leg_debit_or_payee_credit

- **Route**: `POST /api/fabric/trades/{tradeId}/legs/{leg}/{operation}`
- **Auth**: `bearer_auth`
- **Signature**: `def commit_one_fabric_settlement_leg_debit_or_payee_credit(trade_id: str, leg: LegOrStr, operation: OperationOrStr, x_fabric_write_token: str, body: ApiFabricTradesLegsOperationRequest | ApiFabricTradesLegsOperationRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `trade_id`, `leg`, `operation`, `x_fabric_write_token`, `body`
- **Params**: `trade_id` — path `tradeId` · `leg` — path · `operation` — path · `x_fabric_write_token` — header `X-Fabric-Write-Token` · `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody]`
- **Error**: `CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody` — **Case A (typed)**
- **Error arms**: `RawError` [400, 503, anything unmapped]

| Type | Source |
| --- | --- |
| `LegOrStr` | `corridor_flow_cross_border_trade_prototype_api/models/enums/leg.py` |
| `OperationOrStr` | `corridor_flow_cross_border_trade_prototype_api/models/enums/operation.py` |
| `ApiFabricTradesLegsOperationRequest` | `corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_legs_operation_request.py` |
| `ApiFabricTradesLegsOperationRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_legs_operation_request.py` |
| `CommitOneFabricSettlementLegDebitOrPayeeCreditErrorBody` | `corridor_flow_cross_border_trade_prototype_api/errors/commit_one_fabric_settlement_leg_debit_or_payee_credit_error.py` |

### client.create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote

- **Route**: `POST /api/paypal/orders/create`
- **Auth**: `bearer_auth`
- **Signature**: `def create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote(body: ApiPaypalOrdersCreateRequest | ApiPaypalOrdersCreateRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody]`
- **Error**: `CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody` — **Case A (typed)**
- **Error arms**: `RawError` [409, anything unmapped]

| Type | Source |
| --- | --- |
| `ApiPaypalOrdersCreateRequest` | `corridor_flow_cross_border_trade_prototype_api/models/api_paypal_orders_create_request.py` |
| `ApiPaypalOrdersCreateRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/api_paypal_orders_create_request.py` |
| `CreatePayPalOrdersV2OrderSandboxOrSimulationUsingServerCalculatedUsdQuoteErrorBody` | `corridor_flow_cross_border_trade_prototype_api/errors/create_pay_pal_orders_v2_order_sandbox_or_simulation_using_server_calculated_usd_quote_error.py` |

### client.deprecated_direct_settle_endpoint_returns_409_capture_via_api_paypal_orders_id_capture

- **Route**: `POST /trades/{id}/settle`
- **Auth**: `bearer_auth`
- **Signature**: `def deprecated_direct_settle_endpoint_returns_409_capture_via_api_paypal_orders_id_capture(id_: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `id_`
- **Params**: `id_` — path `id`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody]`
- **Error**: `DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody` — **Case A (typed)**
- **Error arms**: `RawError` [409, anything unmapped]

| Type | Source |
| --- | --- |
| `DeprecatedDirectSettleEndpointReturns409CaptureViaApiPaypalOrdersIdCaptureErrorBody` | `corridor_flow_cross_border_trade_prototype_api/errors/deprecated_direct_settle_endpoint_returns409_capture_via_api_paypal_orders_id_capture_error.py` |

### client.dispatch_zapier_outbound_automation_webhook

- **Route**: `POST /api/zapier/trigger`
- **Auth**: `bearer_auth`
- **Signature**: `def dispatch_zapier_outbound_automation_webhook(*, body: ApiZapierTriggerRequest | ApiZapierTriggerRequestDict | None = None, request_options: RequestOptionsOrDict | None = None)`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiZapierTriggerRequest` | `corridor_flow_cross_border_trade_prototype_api/models/api_zapier_trigger_request.py` |
| `ApiZapierTriggerRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/api_zapier_trigger_request.py` |

### client.elastic_observability_financial_crime_search

- **Route**: `GET /api/elastic/search`
- **Auth**: `bearer_auth`
- **Signature**: `def elastic_observability_financial_crime_search(*, q: str | None = None, request_options: RequestOptionsOrDict | None = None)`
- **Params**: `q` — query
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.end_the_current_demo_session

- **Route**: `POST /auth/logout`
- **Auth**: `bearer_auth`
- **Signature**: `def end_the_current_demo_session(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.get_a_local_sha_256_receipt_digest_for_a_demo_settlement

- **Route**: `GET /api/receipts/{tradeId}`
- **Auth**: `bearer_auth`
- **Signature**: `def get_a_local_sha_256_receipt_digest_for_a_demo_settlement(trade_id: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `trade_id`
- **Params**: `trade_id` — path `tradeId`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.get_the_illustrative_usd_funding_quote_for_an_accepted_demo_trade

- **Route**: `GET /api/paypal/orders/quote/{tradeId}`
- **Auth**: `bearer_auth`
- **Signature**: `def get_the_illustrative_usd_funding_quote_for_an_accepted_demo_trade(trade_id: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `trade_id`
- **Params**: `trade_id` — path `tradeId`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.get_the_signed_in_operator_identity_and_role

- **Route**: `GET /me`
- **Auth**: `bearer_auth`
- **Signature**: `def get_the_signed_in_operator_identity_and_role(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.health_and_system_status

- **Route**: `GET /health`
- **Signature**: `def health_and_system_status(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.list_all_active_and_settled_bilateral_trades

- **Route**: `GET /trades`
- **Auth**: `bearer_auth`
- **Signature**: `def list_all_active_and_settled_bilateral_trades(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.marks_the_sample_counterparty_leg_held_in_the_demo_workflow

- **Route**: `POST /trades/{id}/accept`
- **Auth**: `bearer_auth`
- **Signature**: `def marks_the_sample_counterparty_leg_held_in_the_demo_workflow(id_: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `id_`
- **Params**: `id_` — path `id`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.propose_a_new_sample_trade_in_the_demo_workflow

- **Route**: `POST /trades`
- **Auth**: `bearer_auth`
- **Signature**: `def propose_a_new_sample_trade_in_the_demo_workflow(body: TradesRequest | TradesRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `TradesRequest` | `corridor_flow_cross_border_trade_prototype_api/models/trades_request.py` |
| `TradesRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/trades_request.py` |

### client.read_a_live_fabric_chaincode_snapshot

- **Route**: `GET /api/fabric/ledger`
- **Auth**: `bearer_auth`
- **Signature**: `def read_a_live_fabric_chaincode_snapshot(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, ReadALiveFabricChaincodeSnapshotErrorBody]`
- **Error**: `ReadALiveFabricChaincodeSnapshotErrorBody` — **Case A (typed)**
- **Error arms**: `RawError` [503, anything unmapped]

| Type | Source |
| --- | --- |
| `ReadALiveFabricChaincodeSnapshotErrorBody` | `corridor_flow_cross_border_trade_prototype_api/errors/read_a_live_fabric_chaincode_snapshot_error.py` |

### client.retry_a_failed_pay_pal_batch_payout_v1_for_a_settled_demo_trade

- **Route**: `POST /api/paypal/payouts/batch`
- **Auth**: `bearer_auth`
- **Signature**: `def retry_a_failed_pay_pal_batch_payout_v1_for_a_settled_demo_trade(body: ApiPaypalPayoutsBatchRequest | ApiPaypalPayoutsBatchRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiPaypalPayoutsBatchRequest` | `corridor_flow_cross_border_trade_prototype_api/models/api_paypal_payouts_batch_request.py` |
| `ApiPaypalPayoutsBatchRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/api_paypal_payouts_batch_request.py` |

### client.run_deterministic_sample_corridor_blocklist_checks_with_optional_gemini_explanation

- **Route**: `POST /api/ai/risk-screen`
- **Auth**: `bearer_auth`
- **Signature**: `def run_deterministic_sample_corridor_blocklist_checks_with_optional_gemini_explanation(*, body: ApiAiRiskScreenRequest | ApiAiRiskScreenRequestDict | None = None, request_options: RequestOptionsOrDict | None = None)`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiAiRiskScreenRequest` | `corridor_flow_cross_border_trade_prototype_api/models/api_ai_risk_screen_request.py` |
| `ApiAiRiskScreenRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/api_ai_risk_screen_request.py` |

### client.search_channel3_b2_b_product_catalog

- **Route**: `GET /api/channel3/catalog`
- **Auth**: `bearer_auth`
- **Signature**: `def search_channel3_b2_b_product_catalog(*, q: str | None = None, request_options: RequestOptionsOrDict | None = None)`
- **Params**: `q` — query
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

### client.settle_an_accepted_fabric_trade

- **Route**: `POST /api/fabric/trades/{tradeId}/settle`
- **Auth**: `bearer_auth`
- **Signature**: `def settle_an_accepted_fabric_trade(trade_id: str, x_fabric_write_token: str, body: ApiFabricTradesSettleRequest | ApiFabricTradesSettleRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `trade_id`, `x_fabric_write_token`, `body`
- **Params**: `trade_id` — path `tradeId` · `x_fabric_write_token` — header `X-Fabric-Write-Token` · `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, SettleAnAcceptedFabricTradeErrorBody]`
- **Error**: `SettleAnAcceptedFabricTradeErrorBody` — **Case A (typed)**
- **Error arms**: `RawError` [400, 503, anything unmapped]

| Type | Source |
| --- | --- |
| `ApiFabricTradesSettleRequest` | `corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_settle_request.py` |
| `ApiFabricTradesSettleRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_settle_request.py` |
| `SettleAnAcceptedFabricTradeErrorBody` | `corridor_flow_cross_border_trade_prototype_api/errors/settle_an_accepted_fabric_trade_error.py` |

### client.sign_in_to_a_configured_demo_role

- **Route**: `POST /auth/login`
- **Signature**: `def sign_in_to_a_configured_demo_role(body: AuthLoginRequest | AuthLoginRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `AuthLoginRequest` | `corridor_flow_cross_border_trade_prototype_api/models/auth_login_request.py` |
| `AuthLoginRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/auth_login_request.py` |

### client.submit_a_new_inr_sgd_trade_proposal_to_fabric

- **Route**: `POST /api/fabric/trades/propose`
- **Auth**: `bearer_auth`
- **Signature**: `def submit_a_new_inr_sgd_trade_proposal_to_fabric(x_fabric_write_token: str, body: ApiFabricTradesProposeRequest | ApiFabricTradesProposeRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `x_fabric_write_token`, `body`
- **Params**: `x_fabric_write_token` — header `X-Fabric-Write-Token` · `body` — JSON body
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, SubmitANewInrSgdTradeProposalToFabricErrorBody]`
- **Error**: `SubmitANewInrSgdTradeProposalToFabricErrorBody` — **Case A (typed)**
- **Error arms**: `RawError` [400, 503, anything unmapped]

| Type | Source |
| --- | --- |
| `ApiFabricTradesProposeRequest` | `corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_propose_request.py` |
| `ApiFabricTradesProposeRequestDict` | `corridor_flow_cross_border_trade_prototype_api/models/api_fabric_trades_propose_request.py` |
| `SubmitANewInrSgdTradeProposalToFabricErrorBody` | `corridor_flow_cross_border_trade_prototype_api/errors/submit_a_new_inr_sgd_trade_proposal_to_fabric_error.py` |

